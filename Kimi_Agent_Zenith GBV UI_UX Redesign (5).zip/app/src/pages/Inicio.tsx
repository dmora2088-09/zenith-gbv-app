import { useNavigate } from 'react-router';
import { useDiagnostico } from '@/context/DiagnosticoContext';
import { useState, useEffect, useMemo } from 'react';
import {
  Upload,
  FileText,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  Zap,
  Globe,
  TrendingDown,
  Compass,
} from 'lucide-react';

/**
 * ============================================================
 * Zenith GBV — Inicio Premium
 *
 * IDENTIDAD SIEMPRE VISIBLE: El hero con "Zenith / Gestion de Valor"
 * se muestra siempre, sin importar si hay resultados.
 *
 * Cuando hay resultados: tarjeta resumen (Score, EVA, CTAs)
 * aparece DEBAJO del hero, seguida del Bento Grid.
 *
 * Bento Grid balanceado (3 cols, 2 rows):
 *   [Analisis 2rows] [Dashboard]    [Reportes]
 *   [  (continua)  ] [Contexto Macro (col-span-2)]
 *
 * Cuarta tarjeta: Contexto Macroeconomico en tiempo real.
 * ============================================================
 */

export default function Inicio() {
  const navigate = useNavigate();
  const { resultados } = useDiagnostico();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="min-h-[calc(100vh-3.5rem)] -m-6 p-6 overflow-hidden relative">
      {/* Fondo abstracto */}
      <div className="absolute inset-0 z-0">
        <img src="/hero-bg.jpg" alt="" className="w-full h-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-pearl/60 to-pearl" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto">

        {/* ═══════ HERO — SIEMPRE VISIBLE (identidad de marca) ═══ */}
        <HeroBanner visible={visible} resultados={resultados} />

        {/* ═══════ TARJETA RESULTADOS (solo si hay diagnostico) ══ */}
        {resultados && (
          <ResultadosCard
            resultados={resultados}
            visible={visible}
            navigate={navigate}
          />
        )}

        {/* ═══════ BENTO GRID (4 cards, layout balanceado) ══════ */}
        <BentoGrid visible={visible} navigate={navigate} resultados={resultados} />

        {/* ═══════ STATS BAR ════════════════════════════════════ */}
        <StatsBar visible={visible} />
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   HERO BANNER — Identidad de marca, SIEMPRE visible
   ═══════════════════════════════════════════════════════════════ */

function HeroBanner({
  visible,
  resultados,
}: {
  visible: boolean;
  resultados: ReturnType<typeof useDiagnostico>['resultados'];
}) {
  return (
    <div className={`pt-6 pb-8 transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
      <div className="flex items-center gap-3 mb-4">
        {/* Logo azul corporativo — sin contenedor, sin filtros */}
        <img
          src="/logo-inicio-azul.png"
          alt="Zenith"
          className="h-11 w-auto object-contain flex-shrink-0"
          draggable={false}
        />
        <div>
          <h1 className="text-3xl font-bold text-navy-900 tracking-tight leading-none">
            Zenith
          </h1>
          <p className="text-[11px] text-steel-500 tracking-[0.2em] uppercase font-medium mt-1">
            Consultoria Financiera
          </p>
        </div>
      </div>
      <p className="text-base text-[#6b7a8d] max-w-xl leading-relaxed font-light">
        Plataforma de consultoria financiera para PyMEs mexicanas.
        Calculamos el valor economico real de tu empresa y te mostramos
        exactamente donde y como crear mas valor.
      </p>
      {resultados && (
        <p className="text-xs text-success font-medium mt-2">
          Diagnostico activo: <strong className="text-navy-900">{resultados.empresa}</strong>
          {' '}— Score {resultados.score_global}/100
        </p>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   TARJETA RESULTADOS — Aparece debajo del hero, solo con datos
   ═══════════════════════════════════════════════════════════════ */

function ResultadosCard({
  resultados,
  visible,
  navigate,
}: {
  resultados: NonNullable<ReturnType<typeof useDiagnostico>['resultados']>;
  visible: boolean;
  navigate: (path: string) => void;
}) {
  const fmt = useMemo(() => {
    const m = resultados.metricas;
    return {
      eva: m.eva >= 1_000_000
        ? `$${(m.eva / 1_000_000).toFixed(1)}M`
        : m.eva >= 1_000
          ? `$${(m.eva / 1_000).toFixed(0)}K`
          : `$${m.eva.toFixed(0)}`,
      roic: `${(m.roic * 100).toFixed(1)}%`,
      wacc: `${(m.wacc * 100).toFixed(1)}%`,
      scoreColor: resultados.score_global >= 75 ? 'text-success'
        : resultados.score_global >= 50 ? 'text-warning' : 'text-danger',
    };
  }, [resultados]);

  return (
    <div className={`mb-8 transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`} style={{ transitionDelay: '50ms' }}>
      <div className="zn-card p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-navy-900/[0.03] rounded-full -translate-y-16 translate-x-16" />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-6">
            <div className="text-center">
              <p className="text-[10px] text-[#9ba5b3] uppercase tracking-wider mb-0.5">Score</p>
              <p className={`text-3xl font-bold font-mono ${fmt.scoreColor}`}>
                {resultados.score_global}
              </p>
            </div>
            <div className="w-px h-10 bg-[#e8ebf0]" />
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <Compass size={13} className={fmt.scoreColor} />
                <span className={`text-sm font-bold ${fmt.scoreColor}`}>
                  {resultados.veredicto}
                </span>
              </div>
              <p className="text-xs text-[#6b7a8d]">
                {resultados.empresa} &middot; {resultados.sector}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-5">
            <div className="text-right">
              <p className="text-[10px] text-[#9ba5b3] uppercase tracking-wider">EVA</p>
              <p className={`text-xl font-bold font-mono ${resultados.metricas.eva >= 0 ? 'text-success' : 'text-danger'}`}>
                {fmt.eva}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-[#9ba5b3] uppercase tracking-wider">ROIC</p>
              <p className="text-lg font-bold font-mono text-navy-900">{fmt.roic}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-[#9ba5b3] uppercase tracking-wider">WACC</p>
              <p className="text-lg font-bold font-mono text-navy-900">{fmt.wacc}</p>
            </div>
          </div>
        </div>

        {/* CTAs */}
        <div className="flex items-center gap-3 mt-5 pt-5 border-t border-[#f0f2f5]">
          <button onClick={() => navigate('/dashboard')} className="zn-btn-primary">
            <TrendingUp size={14} className="mr-1.5" />
            Ver Dashboard
          </button>
          <button onClick={() => navigate('/ingesta')} className="zn-btn-secondary">
            <Upload size={14} className="mr-1.5" />
            Nuevo Analisis
          </button>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   BENTO GRID — Layout balanceado 3x2
   ═══════════════════════════════════════════════════════════════ */

function BentoGrid({
  visible,
  navigate,
  resultados,
}: {
  visible: boolean;
  navigate: (path: string) => void;
  resultados: ReturnType<typeof useDiagnostico>['resultados'];
}) {
  const hasResultados = !!resultados;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">

      {/* Card 1: Nuevo Analisis (row-span-2, col 1) */}
      <button
        onClick={() => navigate('/ingesta')}
        className={`group relative zn-card p-6 text-left hover:-translate-y-1 cursor-pointer overflow-hidden sm:row-span-2 transition-all duration-500 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
        style={{ transitionDelay: '100ms' }}
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-navy-900/[0.03] rounded-full -translate-y-12 translate-x-12" />
        <div className="w-11 h-11 rounded-xl bg-navy-900 flex items-center justify-center mb-5 shadow-md">
          <Upload size={18} className="text-white" />
        </div>
        <h3 className="text-base font-bold text-navy-900 mb-2">
          Comenzar Nuevo Analisis
        </h3>
        <p className="text-sm text-[#6b7a8d] mb-6 leading-relaxed font-light">
          Ingresa los datos de una empresa y ejecuta el motor de calculo
          para obtener un diagnostico financiero completo.
        </p>
        <span className="inline-flex items-center text-sm font-semibold text-steel-500 group-hover:text-navy-900 transition-colors">
          Iniciar ahora
          <ArrowRight size={14} className="ml-2 group-hover:translate-x-1 transition-transform" />
        </span>
      </button>

      {/* Card 2: Dashboard / Resultados (col 2, row 1) */}
      {hasResultados ? (
        <button
          onClick={() => navigate('/dashboard')}
          className={`group zn-card p-5 text-left hover:-translate-y-1 cursor-pointer border-success/15 transition-all duration-500 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
          style={{ transitionDelay: '200ms' }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-9 h-9 rounded-lg bg-success/10 flex items-center justify-center">
              <TrendingUp size={16} className="text-success" />
            </div>
            <SparklineUp />
          </div>
          <h3 className="text-sm font-bold text-navy-900 mb-1">Dashboard</h3>
          <p className="text-xs text-[#6b7a8d] font-light">
            {resultados.empresa} — Score {resultados.score_global}/100
          </p>
          <span className="inline-flex items-center text-xs font-semibold text-success mt-3">
            Ver ahora <ArrowRight size={12} className="ml-1" />
          </span>
        </button>
      ) : (
        <div
          className={`zn-card p-5 text-left opacity-40 transition-all duration-500 ${visible ? 'opacity-40 translate-y-0' : 'opacity-0 translate-y-6'}`}
          style={{ transitionDelay: '200ms' }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-9 h-9 rounded-lg bg-[#e8ebf0] flex items-center justify-center">
              <TrendingUp size={16} className="text-[#9ba5b3]" />
            </div>
            <SparklineWave />
          </div>
          <h3 className="text-sm font-bold text-navy-900 mb-1">Dashboard</h3>
          <p className="text-xs text-[#6b7a8d] font-light">Los resultados apareceran tras ejecutar un analisis.</p>
        </div>
      )}

      {/* Card 3: Reportes (col 3, row 1) */}
      <div
        className={`zn-card p-5 text-left opacity-40 transition-all duration-500 ${visible ? 'opacity-40 translate-y-0' : 'opacity-0 translate-y-6'}`}
        style={{ transitionDelay: '300ms' }}
      >
        <div className="flex items-center justify-between mb-3">
          <div className="w-9 h-9 rounded-lg bg-[#e8ebf0] flex items-center justify-center">
            <FileText size={16} className="text-[#9ba5b3]" />
          </div>
          <SparklineWave />
        </div>
        <h3 className="text-sm font-bold text-navy-900 mb-1">Reportes</h3>
        <p className="text-xs text-[#6b7a8d] font-light">Genera reportes ejecutivos en Word y Excel.</p>
        <span className="text-[10px] text-[#9ba5b3] mt-2 inline-block">Proximamente</span>
      </div>

      {/* Card 4: Contexto Macroeconomico (cols 2-3, row 2 — llena el hueco) */}
      <div
        className={`zn-card p-5 text-left sm:col-span-2 transition-all duration-500 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
        style={{ transitionDelay: '400ms' }}
      >
        <MacroContexto />
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   CONTEXTO MACROECONOMICO — Card 4 (col-span-2)
   ═══════════════════════════════════════════════════════════════ */

function MacroContexto() {
  const macro = useMemo(() => {
    try {
      const m = (window as any).MotorVBM?.MACRO;
      if (!m) return null;
      return {
        rf: typeof m.Rf === 'number' ? (m.Rf * 100).toFixed(2) + '%' : null,
        inflacion: typeof m.inflacion_INPC === 'number' ? (m.inflacion_INPC * 100).toFixed(2) + '%' : null,
        cetes: typeof m.CETES_28 === 'number' ? (m.CETES_28 * 100).toFixed(2) + '%' : null,
        tiie: typeof m.TIIE_28 === 'number' ? (m.TIIE_28 * 100).toFixed(2) + '%' : null,
        tipoCambio: typeof m.tipo_cambio_USD_MXN === 'number' ? m.tipo_cambio_USD_MXN.toFixed(2) : null,
        fecha: m.fecha_corte || 'Abril 2026',
      };
    } catch {
      return null;
    }
  }, []);

  const items = [
    { label: 'Tasa Libre de Riesgo', value: macro?.rf || '9.50%', icon: <TrendingDown size={12} /> },
    { label: 'Inflacion Esperada', value: macro?.inflacion || '4.59%', icon: <Zap size={12} /> },
    { label: 'CETES 28 dias', value: macro?.cetes || '6.60%', icon: <ShieldCheck size={12} /> },
    { label: 'TIIE 28 dias', value: macro?.tiie || '7.01%', icon: <TrendingUp size={12} /> },
    { label: 'Tipo de Cambio', value: macro?.tipoCambio ? `$${macro.tipoCambio}` : '$17.27', icon: <Globe size={12} /> },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-navy-100 flex items-center justify-center">
            <Globe size={16} className="text-navy-600" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-navy-900">Contexto Macroeconomico</h3>
            <p className="text-[10px] text-[#9ba5b3]">Parametros de referencia para Mexico</p>
          </div>
        </div>
        <span className="text-[10px] text-[#9ba5b3] font-medium">{macro?.fecha || 'Abril 2026'}</span>
      </div>

      <div className="grid grid-cols-5 gap-3">
        {items.map((item) => (
          <div key={item.label} className="text-center">
            <div className="flex items-center justify-center gap-1 text-[#9ba5b3] mb-1">
              {item.icon}
              <span className="text-[10px] text-[#9ba5b3]">{item.label}</span>
            </div>
            <p className="text-sm font-bold font-mono text-navy-900">{item.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-3 pt-2 border-t border-[#f0f2f5] flex items-center gap-1">
        <TrendingDown size={10} className="text-[#9ba5b3]" />
        <span className="text-[10px] text-[#9ba5b3]">Parametros actualizados trimestralmente</span>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   STATS BAR
   ═══════════════════════════════════════════════════════════════ */

function StatsBar({ visible }: { visible: boolean }) {
  return (
    <div
      className={`flex items-center gap-8 px-8 py-5 bg-white/80 backdrop-blur-sm rounded-2xl border border-[#e8ebf0] max-w-3xl transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
      style={{ transitionDelay: '500ms' }}
    >
      <div className="flex items-center gap-2.5">
        <ShieldCheck size={15} className="text-success" />
        <span className="text-xs text-[#6b7a8d] font-light">Motor <strong className="text-navy-900 font-semibold">v3.2</strong></span>
      </div>
      <div className="w-px h-4 bg-[#e8ebf0]" />
      <div className="flex items-center gap-2.5">
        <Zap size={15} className="text-warning" />
        <span className="text-xs text-[#6b7a8d] font-light">Parametros: <strong className="text-navy-900 font-semibold">Abril 2026</strong></span>
      </div>
      <div className="w-px h-4 bg-[#e8ebf0]" />
      <div className="flex items-center gap-2.5">
        <Globe size={15} className="text-steel-500" />
        <span className="text-xs text-[#6b7a8d] font-light"><strong className="text-navy-900 font-semibold">20</strong> sectores analizados</span>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SPARKLINE SVG COMPONENTS
   ═══════════════════════════════════════════════════════════════ */

function SparklineUp() {
  return (
    <svg viewBox="0 0 100 30" className="w-16 h-6 opacity-30">
      <path d="M0 28 L10 26 L20 22 L30 23 L40 18 L50 15 L60 12 L70 14 L80 8 L90 6 L100 2"
        fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="100" cy="2" r="2" fill="currentColor" />
    </svg>
  );
}

function SparklineWave() {
  return (
    <svg viewBox="0 0 100 30" className="w-16 h-6 opacity-30">
      <path d="M0 15 Q12 5, 25 15 T50 15 T75 15 T100 15"
        fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="100" cy="15" r="2" fill="currentColor" />
    </svg>
  );
}
