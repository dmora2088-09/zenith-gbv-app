import { useNavigate } from 'react-router';
import { useDiagnostico } from '@/context/DiagnosticoContext';
import {
  Upload,
  FileText,
  BarChart3,
  ArrowRight,
  Activity,
  TrendingUp,
  ShieldCheck,
  Zap,
} from 'lucide-react';

/**
 * ============================================================
 * Zenith GBV — WelcomeScreen (Pantalla de Inicio)
 *
 * Bento Grid Hero con micro-visualizaciones institucionales.
 * Si hay un diagnostico activo, muestra CTA rapido a resultados.
 * ============================================================
 */

export default function WelcomeScreen() {
  const navigate = useNavigate();
  const { resultados } = useDiagnostico();

  return (
    <div className="min-h-[60vh] animate-fade-in">
      {/* Hero Header */}
      <div className="mb-10">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-navy-900 flex items-center justify-center shadow-md">
            <Activity size={20} className="text-steel-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-navy-900 tracking-tight">
              Zenith GBV
            </h1>
            <p className="text-[11px] text-[#6b7a8d] tracking-widest uppercase font-medium">
              Valuation-Based Management
            </p>
          </div>
        </div>
        <p className="text-sm text-[#6b7a8d] max-w-xl leading-relaxed">
          Plataforma de consultoria financiera para PyMEs mexicanas.
          Calculamos WACC, ROIC, EVA y generamos diagnosticos completos
          con recomendaciones accionables para crear valor economico.
        </p>
      </div>

      {/* Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl">
        {/* Card 1: Nuevo Analisis (destacada) */}
        <button
          onClick={() => navigate('/ingesta')}
          className="zn-card p-6 text-left hover:-translate-y-1 cursor-pointer group relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-navy-900/3 rounded-full -translate-y-8 translate-x-8" />
          <div className="w-10 h-10 rounded-xl bg-navy-900 flex items-center justify-center mb-4 relative z-10">
            <Upload size={17} className="text-white" />
          </div>
          <h3 className="text-sm font-bold text-navy-900 mb-1.5 relative z-10">
            Nuevo Analisis
          </h3>
          <p className="text-xs text-[#6b7a8d] mb-4 leading-relaxed relative z-10">
            Ingresa los datos de una empresa y ejecuta el motor de calculo para obtener un diagnostico completo.
          </p>
          <span className="inline-flex items-center text-xs font-semibold text-steel-500 group-hover:text-navy-900 transition-colors relative z-10">
            Comenzar <ArrowRight size={12} className="ml-1.5 group-hover:translate-x-0.5 transition-transform" />
          </span>
        </button>

        {/* Card 2: Resultados (activa si hay diagnostico) */}
        {resultados ? (
          <button
            onClick={() => navigate('/dashboard')}
            className="zn-card p-6 text-left hover:-translate-y-1 cursor-pointer group border-success/20"
          >
            <div className="w-10 h-10 rounded-xl bg-success/10 flex items-center justify-center mb-4">
              <TrendingUp size={17} className="text-success" />
            </div>
            <h3 className="text-sm font-bold text-navy-900 mb-1.5">
              Ver Resultados
            </h3>
            <p className="text-xs text-[#6b7a8d] mb-3 leading-relaxed">
              {resultados.empresa} — Score: {resultados.score_global}/100
            </p>
            <span className="inline-flex items-center text-xs font-semibold text-success">
              Dashboard <ArrowRight size={12} className="ml-1.5" />
            </span>
          </button>
        ) : (
          <div className="zn-card p-6 text-left opacity-50">
            <div className="w-10 h-10 rounded-xl bg-[#e8ebf0] flex items-center justify-center mb-4">
              <BarChart3 size={17} className="text-[#9ba5b3]" />
            </div>
            <h3 className="text-sm font-bold text-navy-900 mb-1.5">Resultados</h3>
            <p className="text-xs text-[#6b7a8d] mb-3 leading-relaxed">
              Los resultados del diagnostico apareceran aqui.
            </p>
            <span className="text-[10px] text-[#9ba5b3]">Requiere analisis previo</span>
          </div>
        )}

        {/* Card 3: Reportes (placeholder) */}
        <div className="zn-card p-6 text-left opacity-50">
          <div className="w-10 h-10 rounded-xl bg-[#e8ebf0] flex items-center justify-center mb-4">
            <FileText size={17} className="text-[#9ba5b3]" />
          </div>
          <h3 className="text-sm font-bold text-navy-900 mb-1.5">Reportes</h3>
          <p className="text-xs text-[#6b7a8d] mb-3 leading-relaxed">
            Genera reportes ejecutivos en Word y Excel.
          </p>
          <span className="text-[10px] text-[#9ba5b3]">Proximamente</span>
        </div>
      </div>

      {/* Quick stats bar (institucional) */}
      <div className="mt-10 flex items-center gap-8 px-6 py-4 bg-white rounded-xl border border-[#e8ebf0] max-w-3xl">
        <div className="flex items-center gap-2">
          <ShieldCheck size={14} className="text-success" />
          <span className="text-xs text-[#6b7a8d]">Motor <strong className="text-navy-900">v3.2</strong></span>
        </div>
        <div className="w-px h-4 bg-[#e8ebf0]" />
        <div className="flex items-center gap-2">
          <Zap size={14} className="text-warning" />
          <span className="text-xs text-[#6b7a8d]">Parametros: <strong className="text-navy-900">Abril 2026</strong></span>
        </div>
        <div className="w-px h-4 bg-[#e8ebf0]" />
        <div className="flex items-center gap-2">
          <Activity size={14} className="text-steel-500" />
          <span className="text-xs text-[#6b7a8d]"><strong className="text-navy-900">15+</strong> sectores</span>
        </div>
      </div>
    </div>
  );
}
