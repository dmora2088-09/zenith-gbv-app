import { BookOpen, BarChart3, Target, Lightbulb, Scale } from 'lucide-react';

/**
 * ================================================================
 * Metodologia Zenith — Vista de texto estático
 *
 * Explica el marco conceptual de la plataforma:
 *   - Enfoque VBM (Value Based Management)
 *   - Metricas clave: EVA, ROIC, WACC
 *   - Semáforos de salud financiera
 *   - Plan de accion por prioridad
 * ================================================================ */

export default function Metodologia() {
  return (
    <div className="space-y-8 animate-fade-in max-w-3xl mx-auto">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-navy-900 tracking-tight">Metodologia Zenith</h2>
        <p className="text-xs text-[#6b7a8d] mt-1">
          El marco conceptual detras de la plataforma
        </p>
      </div>

      {/* Intro */}
      <div className="zn-card p-6">
        <div className="flex items-start gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-navy-900 flex items-center justify-center flex-shrink-0">
            <BookOpen size={18} className="text-gold" />
          </div>
          <div>
            <h3 className="text-base font-bold text-navy-900 mb-2">Value Based Management (VBM)</h3>
            <p className="text-xs text-[#6b7a8d] leading-relaxed">
              Zenith GBV aplica el enfoque de Gestion Basada en Valor, que mide el desempeno
              financiero no por utilidades contables, sino por la capacidad de crear valor economico
              real sobre el costo del capital invertido.
            </p>
          </div>
        </div>
      </div>

      {/* Metricas clave */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <MetricCard
          icon={<BarChart3 size={16} />}
          title="EVA"
          subtitle="Valor Economico Agregado"
          desc="La ganancia real despues de cubrir el costo de TODO el capital (deuda + patrimonio). Si es positivo, la empresa crea valor."
        />
        <MetricCard
          icon={<Target size={16} />}
          title="ROIC"
          subtitle="Retorno sobre Capital Invertido"
          desc="Mide que tan eficientemente el negocio usa su capital para generar ganancias operativas. Debe superar al WACC."
        />
        <MetricCard
          icon={<Scale size={16} />}
          title="WACC"
          subtitle="Costo de Capital Promedio"
          desc="La tasa minima de retorno que el negocio debe generar para compensar a acreedores y accionistas."
        />
      </div>

      {/* Formula */}
      <div className="zn-card p-6 bg-navy-50/50">
        <div className="flex items-center gap-3 mb-3">
          <Lightbulb size={16} className="text-gold" />
          <h3 className="text-sm font-bold text-navy-900">La Formula del Valor</h3>
        </div>
        <div className="bg-white rounded-lg p-4 border border-navy-100 text-center font-mono text-sm text-navy-800">
          EVA = NOPAT &minus; (Capital Invertido &times; WACC)
        </div>
        <p className="text-xs text-[#6b7a8d] mt-3 leading-relaxed">
          Cuando el ROIC es mayor al WACC, el spread es positivo y la empresa crea valor.
          Cuando es menor, destruye valor aunque reporte utilidades contables.
        </p>
      </div>

      {/* Semaforos */}
      <div className="zn-card p-6">
        <h3 className="text-sm font-bold text-navy-900 mb-4">Semáforos de Salud Financiera</h3>
        <div className="space-y-3">
          <SemRow color="#10b981" label="Saludable" desc="La metrica esta dentro del rango optimo del sector." />
          <SemRow color="#f59e0b" label="Precaucion" desc="La metrica esta por debajo del optimo pero no es critica." />
          <SemRow color="#ef4444" label="Critico" desc="La metrica esta en zona de riesgo. Requiere accion inmediata." />
        </div>
      </div>

      {/* Pilares */}
      <div className="zn-card p-6">
        <h3 className="text-sm font-bold text-navy-900 mb-4">Tres Pilares del Diagnostico</h3>
        <div className="space-y-4">
          <PilarRow num="01" title="Rentabilidad" desc="ROIC, margenes, NOPAT, Z-Score. Evalua si el negocio gana lo suficiente." />
          <PilarRow num="02" title="Liquidez" desc="CCC, DSO, DOH, DPO, dias de caja. Evalua si el negocio tiene suficiente efectivo." />
          <PilarRow num="03" title="Estructura" desc="Deuda/Activos, cobertura, Ke, Kd. Evalua si el financiamiento es sostenible." />
        </div>
      </div>
    </div>
  );
}

/* ── Sub-componentes ── */

function MetricCard({ icon, title, subtitle, desc }: {
  icon: React.ReactNode; title: string; subtitle: string; desc: string;
}) {
  return (
    <div className="zn-card p-5">
      <div className="w-8 h-8 rounded-lg bg-navy-900 flex items-center justify-center mb-3">
        <span className="text-gold">{icon}</span>
      </div>
      <h4 className="text-sm font-bold text-navy-900">{title}</h4>
      <p className="text-[10px] text-[#6b7a8d] font-medium mb-2">{subtitle}</p>
      <p className="text-xs text-[#6b7a8d] leading-relaxed">{desc}</p>
    </div>
  );
}

function SemRow({ color, label, desc }: { color: string; label: string; desc: string }) {
  return (
    <div className="flex items-center gap-3">
      <span style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: color, display: 'inline-block', flexShrink: 0 }} />
      <span className="text-xs font-semibold text-navy-900 w-24">{label}</span>
      <span className="text-xs text-[#6b7a8d]">{desc}</span>
    </div>
  );
}

function PilarRow({ num, title, desc }: { num: string; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="w-6 h-6 rounded-full bg-navy-900 text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0">
        {num}
      </span>
      <div>
        <span className="text-sm font-bold text-navy-900">{title}</span>
        <p className="text-xs text-[#6b7a8d] leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}
