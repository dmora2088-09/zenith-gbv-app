import { useMemo } from 'react';
import { useNavigate } from 'react-router';
import { useDiagnostico } from '@/context/DiagnosticoContext';
import { useFormatters } from '@/hooks/useFormatters';
import { useClasificacionColor, scoreToClasificacion } from '@/hooks/useClasificacionColor';
import SemaforoBadge from '@/components/shared/SemaforoBadge';
import {
  TrendingUp,
  Target,
  CircleDollarSign,
  CheckCircle2,
  XCircle,
  ShieldAlert,
  ArrowRight,
  Compass,
  Lightbulb,
  AlertTriangle,
  BarChart3,
} from 'lucide-react';

/**
 * ============================================================
 * Zenith GBV — Dashboard (Dashboard con resultados)
 *
 * Jerarquia visual:
 *   1. KPIs (5 cards)
 *   2. FODA Cartesiano
 *   3. Alertas de Supervivencia (si hay)
 *   4. Top 4 Estrategias de Optimizacion
 *
 * Regla Top 4:
 *   - Si hay overrides_activos → mostrar esos (max 4)
 *   - Si no → top 4 metas_activas por impacto EVA
 * ============================================================
 */

export default function DashboardResumen() {
  const navigate = useNavigate();
  const { resultados } = useDiagnostico();
  const { pct, compactNumber } = useFormatters();

  if (!resultados) {
    return <EstadoVacio />;
  }

  const m = resultados.metricas;
  const c = resultados.clasificaciones;
  const scoreColor = useClasificacionColor(scoreToClasificacion(resultados.score_global));

  /* ── Z-Score helpers ─────────────────────────────────────── */
  const zScore = resultados.z_score ?? m.z_score ?? null;
  const zZona = resultados.z_zona ?? m.z_zona ?? null;
  const zClasif = zZona === 'Quiebra' ? 'rojo' : zZona === 'Gris' ? 'amb' : 'verde';
  const zLabel = zZona === 'Quiebra' ? 'Peligro de Quiebra'
    : zZona === 'Gris' ? 'Zona de Precaucion'
    : zZona === 'Segura' ? 'Zona Segura' : 'Sin calcular';

  /* ── 5 KPIs ──────────────────────────────────────────────── */
  const kpis = [
    {
      label: 'EVA',
      value: compactNumber(m.eva),
      clasif: m.eva >= 0 ? 'verde' : 'rojo' as const,
      icon: <CircleDollarSign size={15} />,
      desc: m.eva >= 0 ? 'Valor economico agregado' : 'Destruccion de valor',
    },
    {
      label: 'ROIC',
      value: pct(m.roic),
      clasif: c.roic,
      icon: <TrendingUp size={15} />,
      desc: 'Retorno sobre capital invertido',
    },
    {
      label: 'WACC',
      value: pct(m.wacc),
      clasif: 'na' as const,
      icon: <Target size={15} />,
      desc: 'Costo promedio ponderado de capital',
    },
    {
      label: 'Z-Score',
      value: zScore !== null ? zScore.toFixed(2) : 'N/A',
      clasif: zClasif as 'verde' | 'amb' | 'rojo',
      icon: <ShieldAlert size={15} />,
      desc: zLabel,
    },
    {
      label: 'Veredicto',
      value: resultados.crea_valor ? 'Crea Valor' : 'Destruye Valor',
      clasif: resultados.crea_valor ? 'verde' : 'rojo' as const,
      icon: resultados.crea_valor ? <CheckCircle2 size={15} /> : <XCircle size={15} />,
      desc: resultados.veredicto,
    },
  ];

  /* ── Semáforos ───────────────────────────────────────────── */
  const semaforos = [
    { label: 'Rentabilidad', value: resultados.semaforos.rentabilidad },
    { label: 'Liquidez', value: resultados.semaforos.liquidez },
    { label: 'Estructura', value: resultados.semaforos.estructura },
  ];

  /* ── Top 4 Estrategias ───────────────────────────────────── */
  const top4 = useMemo(() => {
    // Si hay overrides de supervivencia → mostrar esos primero (max 4)
    if (resultados.overrides_activos.length > 0) {
      return { tipo: 'supervivencia' as const, items: resultados.overrides_activos.slice(0, 4) };
    }
    // Si no → top 4 metas por impacto EVA descendente
    const sorted = [...resultados.metas_activas]
      .sort((a, b) => b.impacto_eva_calculado - a.impacto_eva_calculado)
      .slice(0, 4);
    return { tipo: 'optimizacion' as const, items: sorted };
  }, [resultados]);

  return (
    <div className="space-y-6 animate-fade-in">

      {/* ═══════ HEADER ═══════════════════════════════════════ */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-navy-900 tracking-tight">
            {resultados.empresa}
          </h2>
          <p className="text-xs text-[#6b7a8d] mt-1">
            {resultados.sector} &middot; {resultados.estrato} &middot; Periodo: {resultados.periodo}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold"
            style={{ backgroundColor: scoreColor.bg, color: scoreColor.text }}
          >
            <Compass size={13} />
            Score: {resultados.score_global} / 100
          </div>
          <SemaforoBadge
            clasificacion={resultados.crea_valor ? 'verde' : 'rojo'}
            label={resultados.veredicto}
          />
          {}
        </div>
      </div>

      {/* ═══════ KPI CARDS (5) ════════════════════════════════ */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {kpis.map((kpi) => {
          const color = useClasificacionColor(kpi.clasif);
          return (
            <div key={kpi.label} className="zn-card p-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-navy-400">{kpi.icon}</span>
                <span className="zn-metric-label">{kpi.label}</span>
              </div>
              <div className="flex items-baseline gap-1.5 mb-1">
                <span className="zn-metric-value">{kpi.value}</span>
                {kpi.clasif !== 'na' && (
                  <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: color.dot }} />
                )}
              </div>
              <p className="text-[11px] text-[#6b7a8d]">{kpi.desc}</p>
            </div>
          );
        })}
      </div>

      {/* ═══════ LAYOUT 2 COLUMNAS ════════════════════════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* ── Columna izquierda (2/3) ───────────────────────── */}
        <div className="lg:col-span-2 space-y-6">

          {/* FODA CARTESIANO — prioridad alta */}
          <FodaCartesiano
            ejeInterno={resultados.foda.eje_interno}
            ejeExterno={resultados.foda.eje_externo}
            cuadrante={resultados.foda.cuadrante}
            preguntaGuia={resultados.foda.pregunta_guia}
          />

          {/* TOP 4: Supervivencia u Optimizacion */}
          {top4.tipo === 'supervivencia' ? (
            <AlertasSupervivencia
              overrides={resultados.overrides_activos}
              alertas={resultados.alertas}
            />
          ) : (
            <div className="zn-card">
              <div className="zn-card-header">
                <div className="flex items-center gap-2">
                  <Lightbulb size={14} className="text-warning" />
                  <span className="zn-card-title">Estrategias Prioritarias (Top 4)</span>
                </div>
                <span className="text-[11px] text-[#6b7a8d]">
                  {resultados.metas_activas.length} totales
                </span>
              </div>
              <div className="divide-y divide-[#f0f2f5]">
                {(top4.items as typeof resultados.metas_activas).map((meta, i) => (
                  <MetaRow key={meta.id} meta={meta} index={i} compactNumber={compactNumber} />
                ))}
                {top4.items.length === 0 && (
                  <div className="px-5 py-8 text-center">
                    <CheckCircle2 size={20} className="text-success mx-auto mb-2" />
                    <p className="text-xs text-[#6b7a8d]">No hay estrategias de optimizacion activas.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* ── Columna derecha (1/3) ─────────────────────────── */}
        <div className="space-y-6">

          {/* Score gauge */}
          <div className="zn-card">
            <div className="zn-card-header">
              <span className="zn-card-title">Score Global</span>
            </div>
            <div className="zn-card-body flex flex-col items-center">
              <div className="relative w-32 h-32 mb-3">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
                  <circle cx="60" cy="60" r="50" fill="none" stroke="#e8ebf0" strokeWidth="10" />
                  <circle
                    cx="60" cy="60" r="50" fill="none"
                    stroke={scoreColor.dot}
                    strokeWidth="10"
                    strokeLinecap="round"
                    strokeDasharray={`${(resultados.score_global / 100) * 314} 314`}
                    className="transition-all duration-700"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-navy-900">{resultados.score_global}</span>
                  <span className="text-[10px] text-[#6b7a8d]">de 100</span>
                </div>
              </div>
              <p className="text-xs text-[#6b7a8d] text-center">{resultados.texto_cliente}</p>
            </div>
          </div>

          {/* Semáforos por pilar */}
          <div className="zn-card">
            <div className="zn-card-header">
              <span className="zn-card-title">Semaforos por Pilar</span>
            </div>
            <div className="zn-card-body space-y-3">
              {semaforos.map((s) => (
                <div key={s.label} className="flex items-center justify-between">
                  <span className="text-sm text-navy-800">{s.label}</span>
                  <SemaforoBadge clasificacion={s.value} />
                </div>
              ))}
            </div>
          </div>

          {/* Metricas clave */}
          <div className="zn-card">
            <div className="zn-card-header">
              <span className="zn-card-title">Metricas Clave</span>
            </div>
            <div className="zn-card-body space-y-3">
              <MetricRow label="Margen Bruto" value={pct(m.margen_bruto)} clasif={c.margen_bruto} />
              <MetricRow label="Margen EBITDA" value={pct(m.margen_ebitda)} clasif={c.margen_ebitda} />
              <MetricRow label="CCC" value={`${Math.round(m.ccc)} dias`} clasif={c.ccc} />
              <MetricRow label="Razon Corriente" value={m.razon_corriente?.toFixed(2) || 'N/A'} clasif={c.razon_corriente} />
              <MetricRow label="Deuda/Activos" value={pct(m.deuda_activos, 1)} clasif={c.deuda_activos} />
              <MetricRow label="Cobertura" value={m.cobertura_intereses?.toFixed(1) || 'N/A'} clasif={c.cobertura_intereses} />
            </div>
          </div>
        </div>
      </div>

      {/* CTA: Continuar a Analisis Detallado */}
      <div className="flex justify-center pt-4 pb-2">
        <button
          onClick={() => navigate('/resultados/diagnostico')}
          className="flex items-center gap-2 px-6 py-3 bg-navy-900 text-white text-sm font-semibold rounded-lg hover:bg-navy-800 transition-colors shadow-md"
        >
          Continuar a Analisis Detallado
          <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   ESTADO VACIO — Sin diagnostico activo en /dashboard
   ═══════════════════════════════════════════════════════════════ */

function EstadoVacio() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] text-center animate-fade-in">
      <div className="w-14 h-14 rounded-2xl bg-pearl flex items-center justify-center mb-5">
        <BarChart3 size={26} className="text-navy-400" />
      </div>
      <h2 className="text-xl font-bold text-navy-900 mb-2">Sin diagnostico activo</h2>
      <p className="text-sm text-[#6b7a8d] max-w-md mb-6">
        No hay resultados de diagnostico disponibles. Ejecuta un nuevo analisis para ver el Dashboard.
      </p>
      <button onClick={() => navigate('/ingesta')} className="zn-btn-primary">
        Nuevo Analisis <ArrowRight size={14} className="ml-2" />
      </button>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   META ROW — Fila de estrategia con Actual → Meta
   ═══════════════════════════════════════════════════════════════ */

function MetaRow({ meta, index, compactNumber }: {
  meta: {
    id: string;
    nombre: string;
    texto_cliente: string;
    meta_metrica: string | null;
    prioridad: string;
    pilar: string;
    impacto_eva_calculado: number;
    valor_actual: number | null;
    valor_meta_calculado: number | null;
  };
  index: number;
  compactNumber: (n: number) => string;
}) {
  const actual = meta.valor_actual;
  const metaVal = meta.valor_meta_calculado;
  const metrica = meta.meta_metrica;
  const esPct = metrica?.startsWith('margen') || metrica === 'roic' || metrica === 'wacc';
  const esDias = metrica === 'ccc' || metrica === 'dso' || metrica === 'doh' || metrica === 'dpo';
  const esX = metrica === 'cobertura_intereses' || metrica === 'razon_corriente';

  const fmtVal = (v: number | null) => {
    if (v == null) return 'N/A';
    if (esPct) return `${(v * 100).toFixed(1)}%`;
    if (esDias) return `${Math.round(v)} dias`;
    if (esX) return `${v.toFixed(2)}x`;
    return v.toFixed(2);
  };

  return (
    <div className="px-5 py-4 hover:bg-[#f8f9fb] transition-colors">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 w-5 h-5 rounded-full bg-navy-100 text-navy-700 flex items-center justify-center text-[10px] font-bold flex-shrink-0">
          {index + 1}
        </span>
        <div className="flex-1">
          <h4 className="text-sm font-semibold text-navy-900 mb-1">
            {meta.nombre?.trim() || metrica || 'Estrategia'}
          </h4>
          {(actual != null || metaVal != null) && (
            <p className="text-[11px] font-medium text-navy-600 mb-1.5">
              <span className="text-[#9ba5b3]">Actual:</span>{' '}
              <span className="font-semibold">{fmtVal(actual)}</span>
              {' '}<ArrowRight size={10} className="inline text-[#b0b8c4] mx-0.5" />{' '}
              <span className="text-[#9ba5b3]">Meta:</span>{' '}
              <span className="font-semibold text-success">{fmtVal(metaVal)}</span>
            </p>
          )}
          <p className="text-xs text-[#6b7a8d] leading-relaxed">{meta.texto_cliente}</p>
          <div className="flex items-center gap-2 mt-2">
            <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
              meta.prioridad === 'alta' ? 'bg-warning/10 text-warning-dark' :
              meta.prioridad === 'media' ? 'bg-pearl text-[#6b7a8d]' :
              'bg-pearl text-[#9ba5b3]'
            }`}>
              {meta.prioridad.toUpperCase()}
            </span>
            <span className="text-[10px] text-[#9ba5b3] capitalize">{meta.pilar}</span>
            {meta.impacto_eva_calculado !== 0 && (
              <span className="ml-auto text-[10px] font-semibold text-success">
                +{compactNumber(meta.impacto_eva_calculado)} EVA
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   FODA CARTESIANO
   ═══════════════════════════════════════════════════════════════ */

function FodaCartesiano({
  ejeInterno,
  ejeExterno,
  cuadrante,
  preguntaGuia,
}: {
  ejeInterno: number;
  ejeExterno: number;
  cuadrante: 'Ofensiva' | 'Defensiva' | 'Reingenieria' | 'Supervivencia';
  preguntaGuia: string;
}) {
  const x = Math.max(-1, Math.min(1, ejeExterno));
  const y = Math.max(-1, Math.min(1, ejeInterno));
  const scale = 160;
  const cx = 200 + x * scale;
  const cy = 200 - y * scale;

  const cuadrantes = {
    q1: { bg: '#ecfdf5', label: 'Expansion', color: '#10b981' },
    q2: { bg: '#eff6ff', label: 'Fortaleza', color: '#3b82f6' },
    q3: { bg: '#fef2f2', label: 'Supervivencia', color: '#ef4444' },
    q4: { bg: '#fffbeb', label: 'Reorientacion', color: '#f59e0b' },
  };

  const cuadranteColor =
    cuadrante === 'Ofensiva' ? cuadrantes.q1.color :
    cuadrante === 'Defensiva' ? cuadrantes.q2.color :
    cuadrante === 'Supervivencia' ? cuadrantes.q3.color :
    cuadrantes.q4.color;

  return (
    <div className="zn-card">
      <div className="zn-card-header">
        <span className="zn-card-title">Estrategia FODA Ponderado</span>
        <span
          className="text-[11px] font-semibold px-2 py-0.5 rounded-full"
          style={{ backgroundColor: `${cuadranteColor}15`, color: cuadranteColor }}
        >
          {cuadrante}
        </span>
      </div>
      <div className="zn-card-body">
        <p className="text-xs text-[#6b7a8d] leading-relaxed mb-4">{preguntaGuia}</p>
        <div className="flex justify-center">
          <svg viewBox="0 0 400 400" className="w-full max-w-[380px]">
            <defs>
              <filter id="glow">
                <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                <feMerge><feMergeNode in="coloredBlur" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
            </defs>
            <rect x="200" y="0" width="200" height="200" fill={cuadrantes.q1.bg} />
            <rect x="0" y="0" width="200" height="200" fill={cuadrantes.q2.bg} />
            <rect x="0" y="200" width="200" height="200" fill={cuadrantes.q3.bg} />
            <rect x="200" y="200" width="200" height="200" fill={cuadrantes.q4.bg} />
            <text x="300" y="20" textAnchor="middle" fontSize="10" fill={cuadrantes.q1.color} fontWeight="600">Expansion</text>
            <text x="100" y="20" textAnchor="middle" fontSize="10" fill={cuadrantes.q2.color} fontWeight="600">Fortaleza</text>
            <text x="100" y="395" textAnchor="middle" fontSize="10" fill={cuadrantes.q3.color} fontWeight="600">Supervivencia</text>
            <text x="300" y="395" textAnchor="middle" fontSize="10" fill={cuadrantes.q4.color} fontWeight="600">Reorientacion</text>
            <line x1="0" y1="200" x2="400" y2="200" stroke="#cbd5e1" strokeWidth="1.5" />
            <line x1="200" y1="0" x2="200" y2="400" stroke="#cbd5e1" strokeWidth="1.5" />
            {[0.5, -0.5].map((tick) => (
              <g key={tick}>
                <line x1={200 + tick * scale} y1="10" x2={200 + tick * scale} y2="390" stroke="#e2e8f0" strokeWidth="0.5" strokeDasharray="4 4" />
                <line x1="10" y1={200 - tick * scale} x2="390" y2={200 - tick * scale} stroke="#e2e8f0" strokeWidth="0.5" strokeDasharray="4 4" />
              </g>
            ))}
            <text x="395" y="215" textAnchor="end" fontSize="9" fill="#94a3b8" fontWeight="500">Externo (+)</text>
            <text x="10" y="215" textAnchor="start" fontSize="9" fill="#94a3b8" fontWeight="500">Externo (-)</text>
            <text x="210" y="15" textAnchor="start" fontSize="9" fill="#94a3b8" fontWeight="500">Interno (+)</text>
            <text x="210" y="395" textAnchor="start" fontSize="9" fill="#94a3b8" fontWeight="500">Interno (-)</text>
            <circle cx={cx} cy={cy} r="8" fill={cuadranteColor} filter="url(#glow)" opacity="0.2" />
            <circle cx={cx} cy={cy} r="5" fill={cuadranteColor} stroke="white" strokeWidth="2" />
            <text x={cx} y={cy - 14} textAnchor="middle" fontSize="10" fill={cuadranteColor} fontWeight="700" fontFamily="monospace">
              ({x.toFixed(2)}, {y.toFixed(2)})
            </text>
          </svg>
        </div>
        <div className="flex items-center justify-center gap-6 mt-2 pt-3 border-t border-[#f0f2f5]">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: cuadranteColor }} />
            <span className="text-[11px] text-[#6b7a8d]">{cuadrante}</span>
          </div>
          <span className="text-[11px] text-[#9ba5b3]">
            Eje Interno: {ejeInterno.toFixed(2)} &middot; Eje Externo: {ejeExterno.toFixed(2)}
          </span>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   ALERTAS DE SUPERVIVENCIA
   ═══════════════════════════════════════════════════════════════ */

function AlertasSupervivencia({
  overrides,
  alertas,
}: {
  overrides: string[];
  alertas: string[];
}) {
  if (!overrides.length) return null;

  return (
    <div className="rounded-xl border border-danger/20 bg-danger/5 overflow-hidden animate-fade-in">
      <div className="flex items-center gap-2 px-5 py-3 bg-danger/10 border-b border-danger/15">
        <ShieldAlert size={15} className="text-danger" />
        <h3 className="text-sm font-bold text-danger uppercase tracking-wider">
          Accion de Supervivencia — Ejecucion Inmediata
        </h3>
        <span className="ml-auto text-[11px] font-bold text-danger bg-white/70 px-2 py-0.5 rounded-full">
          {overrides.length} alerta{overrides.length > 1 ? 's' : ''}
        </span>
      </div>
      <div className="divide-y divide-danger/10">
        {alertas.slice(0, 4).map((alerta, idx) => (
          <div key={idx} className="px-5 py-3.5 flex items-start gap-3">
            <AlertTriangle size={14} className="text-danger flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-danger-dark">{alerta}</h4>
              <p className="text-[11px] text-danger/70 mt-0.5">Accion de Ejecucion Inmediata</p>
            </div>
          </div>
        ))}
        {overrides.length > 4 && (
          <div className="px-5 py-2.5 text-center text-[11px] text-danger/60">
            +{overrides.length - 4} alertas adicionales en Plan de Accion
          </div>
        )}
      </div>

    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   COMPONENTES AUXILIARES
   ═══════════════════════════════════════════════════════════════ */

function MetricRow({ label, value, clasif }: { label: string; value: string; clasif: string }) {
  const color = useClasificacionColor(clasif);
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs text-[#6b7a8d]">{label}</span>
      <div className="flex items-center gap-2">
        <span className="text-sm font-semibold text-navy-900">{value}</span>
        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: color.dot }} />
      </div>
    </div>
  );
}
