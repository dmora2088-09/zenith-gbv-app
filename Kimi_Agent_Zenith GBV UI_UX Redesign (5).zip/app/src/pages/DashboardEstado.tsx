import { useDiagnostico } from '@/context/DiagnosticoContext';
import { useFormatters } from '@/hooks/useFormatters';
import SemaforoBadge from '@/components/shared/SemaforoBadge';
import { BarChart3 } from 'lucide-react';

export default function DashboardEstado() {
  const { resultados } = useDiagnostico();
  const { pct, fmt } = useFormatters();

  if (!resultados) return null;

  const m = resultados.metricas;
  const c = resultados.clasificaciones;

  const estadoResultados = [
    { label: 'Ventas Netas', value: fmt(m.ventas), clasif: 'na', bold: true },
    { label: 'Costo de Ventas (COGS)', value: fmt(m.cogs), clasif: 'na', indent: true },
    { label: 'Utilidad Bruta', value: fmt(m.utilidad_bruta), clasif: c.margen_bruto, bold: true, highlight: true },
    { label: 'Gastos Operativos (OPEX)', value: fmt(m.opex), clasif: 'na', indent: true },
    { label: 'Depreciacion y Amortizacion', value: fmt(resultados.metricas.ebitda - resultados.metricas.ebit), clasif: 'na', indent: true },
    { label: 'EBITDA', value: fmt(m.ebitda), clasif: c.margen_ebitda, bold: true, highlight: true },
    { label: 'EBIT', value: fmt(m.ebit), clasif: c.margen_operativo, bold: true, highlight: true },
    { label: 'Gastos Financieros', value: fmt(resultados.metricas.ebit - resultados.metricas.utilidad_neta - (resultados.metricas.ebit - resultados.metricas.utilidad_neta)), clasif: 'na', indent: true },
    { label: 'Utilidad Neta', value: fmt(m.utilidad_neta), clasif: c.margen_neto, bold: true, highlight: true },
  ];

  const margenes = [
    { label: 'Margen Bruto', value: pct(m.margen_bruto), clasif: c.margen_bruto },
    { label: 'Margen EBITDA', value: pct(m.margen_ebitda), clasif: c.margen_ebitda },
    { label: 'Margen Operativo', value: pct(m.margen_operativo), clasif: c.margen_operativo },
    { label: 'Margen Neto', value: pct(m.margen_neto), clasif: c.margen_neto },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-navy-900">Estado de Resultados</h2>
        <BarChart3 size={18} className="text-navy-400" />
      </div>

      {/* Estado de Resultados */}
      <div className="zn-card">
        <div className="zn-card-header">
          <span className="zn-card-title">Cuenta de Resultados Consolidada</span>
        </div>
        <div className="zn-card-body">
          <table className="w-full">
            <tbody className="divide-y divide-[#f0f2f5]">
              {estadoResultados.map((row, i) => (
                <tr key={i} className={row.highlight ? 'bg-pearl/50' : ''}>
                  <td className={`py-3 ${row.indent ? 'pl-6' : 'pl-3'} ${row.bold ? 'font-semibold' : ''} text-sm text-navy-800`}>
                    {row.label}
                  </td>
                  <td className={`py-3 pr-3 text-right ${row.bold ? 'font-bold text-navy-900' : 'text-navy-700'} text-sm`}>
                    {row.value}
                  </td>
                  <td className="py-3 pr-3 text-right w-24">
                    {row.clasif !== 'na' && <SemaforoBadge clasificacion={row.clasif} size="sm" />}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Margenes */}
      <div className="zn-card">
        <div className="zn-card-header">
          <span className="zn-card-title">Margenes</span>
        </div>
        <div className="zn-card-body">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {margenes.map((m) => (
              <div key={m.label} className="p-4 rounded-lg bg-pearl">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-[#6b7a8d] uppercase tracking-wider">{m.label}</span>
                  <SemaforoBadge clasificacion={m.clasif} size="sm" />
                </div>
                <span className="text-xl font-bold text-navy-900">{m.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ROE y ROA */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="zn-card p-5">
          <span className="zn-metric-label">ROE</span>
          <div className="text-2xl font-bold text-navy-900 mt-1">{pct(m.roe)}</div>
          <p className="text-[11px] text-[#6b7a8d] mt-1">Retorno sobre patrimonio</p>
        </div>
        <div className="zn-card p-5">
          <span className="zn-metric-label">ROA</span>
          <div className="text-2xl font-bold text-navy-900 mt-1">{pct(m.roa)}</div>
          <p className="text-[11px] text-[#6b7a8d] mt-1">Retorno sobre activos totales</p>
        </div>
      </div>
    </div>
  );
}
