import { useDiagnostico } from '@/context/DiagnosticoContext';
import { useFormatters } from '@/hooks/useFormatters';
import SemaforoBadge from '@/components/shared/SemaforoBadge';
import { ShieldCheck } from 'lucide-react';

export default function DashboardBalance() {
  const { resultados, inputs } = useDiagnostico();
  const { fmt } = useFormatters();

  if (!resultados) return null;

  const m = resultados.metricas;
  const c = resultados.clasificaciones;

  const activos_corrientes = (inputs?.caja_bancos || 0) + (inputs?.cuentas_por_cobrar || 0) + (inputs?.inventarios || 0) + (inputs?.otros_activos_corrientes || 0);

  const activos = [
    { label: 'Caja y Bancos', value: fmt(inputs?.caja_bancos || 0) },
    { label: 'Cuentas por Cobrar', value: fmt(inputs?.cuentas_por_cobrar || 0) },
    { label: 'Inventarios', value: fmt(inputs?.inventarios || 0) },
    { label: 'Activos Fijos Netos', value: fmt(inputs?.activos_fijos_netos || 0) },
    { label: 'Activos Corrientes', value: fmt(activos_corrientes), bold: true },
    { label: 'ACTIVO TOTAL', value: fmt(m.activo_total), bold: true, highlight: true },
  ];

  const pasivos = [
    { label: 'Deuda Corto Plazo', value: fmt(inputs?.deuda_financiera_cp || 0) },
    { label: 'Deuda Largo Plazo', value: fmt(inputs?.deuda_financiera_lp || 0) },
    { label: 'Deuda Total', value: fmt(m.deuda_total), bold: true },
    { label: 'Patrimonio', value: fmt(m.patrimonio), bold: true },
    { label: 'PASIVO + PATRIMONIO', value: fmt((inputs?.deuda_total || 0) + (inputs?.patrimonio || m.patrimonio)), bold: true, highlight: true },
  ];

  const estructura = [
    { label: 'Deuda / Activos', value: (m.deuda_activos * 100).toFixed(1) + '%', clasif: c.deuda_activos },
    { label: 'Deuda / Patrimonio', value: m.deuda_patrimonio.toFixed(2) + 'x', clasif: c.deuda_patrimonio },
    { label: 'Cobertura de Intereses', value: m.cobertura_intereses ? m.cobertura_intereses.toFixed(1) + 'x' : 'N/A', clasif: c.cobertura_intereses },
    { label: 'Razon Corriente', value: m.razon_corriente ? m.razon_corriente.toFixed(2) : 'N/A', clasif: c.razon_corriente },
    { label: 'Prueba Acida', value: m.prueba_acida ? m.prueba_acida.toFixed(2) : 'N/A', clasif: c.prueba_acida },
    { label: 'Z-Score Altman', value: m.z_score ? m.z_score.toFixed(2) : 'N/A', clasif: m.z_score && m.z_score > 2.6 ? 'verde' : m.z_score && m.z_score > 1.1 ? 'amarillo' : 'rojo' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-navy-900">Balance General y Estructura Financiera</h2>
        <ShieldCheck size={18} className="text-navy-400" />
      </div>

      {/* Balance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Activos */}
        <div className="zn-card">
          <div className="zn-card-header">
            <span className="zn-card-title">Activos</span>
          </div>
          <div className="zn-card-body">
            <table className="w-full">
              <tbody className="divide-y divide-[#f0f2f5]">
                {activos.map((row, i) => (
                  <tr key={i} className={row.highlight ? 'bg-pearl/50' : ''}>
                    <td className={`py-2.5 text-sm ${row.bold ? 'font-semibold text-navy-900' : 'text-navy-700'}`}>
                      {row.label}
                    </td>
                    <td className={`py-2.5 text-right text-sm ${row.bold ? 'font-bold text-navy-900' : 'text-navy-700'}`}>
                      {row.value}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pasivos */}
        <div className="zn-card">
          <div className="zn-card-header">
            <span className="zn-card-title">Pasivo y Patrimonio</span>
          </div>
          <div className="zn-card-body">
            <table className="w-full">
              <tbody className="divide-y divide-[#f0f2f5]">
                {pasivos.map((row, i) => (
                  <tr key={i} className={row.highlight ? 'bg-pearl/50' : ''}>
                    <td className={`py-2.5 text-sm ${row.bold ? 'font-semibold text-navy-900' : 'text-navy-700'}`}>
                      {row.label}
                    </td>
                    <td className={`py-2.5 text-right text-sm ${row.bold ? 'font-bold text-navy-900' : 'text-navy-700'}`}>
                      {row.value}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Ratios de estructura */}
      <div className="zn-card">
        <div className="zn-card-header">
          <span className="zn-card-title">Ratios de Estructura Financiera</span>
        </div>
        <div className="zn-card-body">
          <table className="w-full zn-table">
            <thead>
              <tr>
                <th>Ratio</th>
                <th>Valor</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {estructura.map((row) => {
                return (
                  <tr key={row.label}>
                    <td className="font-medium text-navy-800">{row.label}</td>
                    <td className="font-semibold text-navy-900">{row.value}</td>
                    <td>
                      <SemaforoBadge clasificacion={row.clasif} size="sm" />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* CCC */}
      {m.ccc !== null && (
        <div className="zn-card">
          <div className="zn-card-header">
            <span className="zn-card-title">Capital de Trabajo (CCC)</span>
          </div>
          <div className="zn-card-body">
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="p-4 rounded-lg bg-pearl text-center">
                <div className="text-[10px] font-semibold text-[#6b7a8d] uppercase tracking-wider mb-1">DSO</div>
                <div className="text-xl font-bold text-navy-900">{Math.round(m.dso)}d</div>
                <div className="text-[10px] text-[#6b7a8d] mt-0.5">Dias de cobro</div>
              </div>
              <div className="p-4 rounded-lg bg-pearl text-center">
                <div className="text-[10px] font-semibold text-[#6b7a8d] uppercase tracking-wider mb-1">DOH</div>
                <div className="text-xl font-bold text-navy-900">{Math.round(m.doh)}d</div>
                <div className="text-[10px] text-[#6b7a8d] mt-0.5">Dias de inventario</div>
              </div>
              <div className="p-4 rounded-lg bg-pearl text-center">
                <div className="text-[10px] font-semibold text-[#6b7a8d] uppercase tracking-wider mb-1">DPO</div>
                <div className="text-xl font-bold text-navy-900">{Math.round(m.dpo)}d</div>
                <div className="text-[10px] text-[#6b7a8d] mt-0.5">Dias de pago</div>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg bg-navy-900">
              <span className="text-sm font-semibold text-white">Ciclo de Conversion de Efectivo (CCC)</span>
              <span className={`text-xl font-bold ${m.ccc <= 30 ? 'text-success' : m.ccc <= 60 ? 'text-warning' : 'text-danger'}`}>
                {Math.round(m.ccc)} dias
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
