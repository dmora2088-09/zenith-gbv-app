import { useNavigate } from 'react-router';
import { useDiagnostico } from '@/context/DiagnosticoContext';
import { useFormatters } from '@/hooks/useFormatters';
import { limpiarJerga } from '@/lib/limpiarJerga';
import { getCatalogoMetas } from '@/engine/motorAdapter';
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion';
import {
  Target,
  ArrowRight,
  Lightbulb,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  ClipboardList,
  ShieldAlert,
} from 'lucide-react';

/**
 * ============================================================
 * Zenith GBV — Plan de Accion Completo
 *
 * Lista TODAS las metas_activas (sin limite Top 4).
 * Cada meta expandible via Accordion de shadcn/ui.
 *
 * TEXTO_CONSULTOR renderizado fielmente como lista de
 * acciones concretas. Sin resumir. Sin frases introductorias
 * redundantes.
 *
 * Todas las siglas financieras se purgan via limpiarJerga().
 * ============================================================
 */

export default function PlanAccion() {
  const { resultados } = useDiagnostico();
  const { compactNumber } = useFormatters();
  const navigate = useNavigate();

  if (!resultados) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center animate-fade-in">
        <div className="w-14 h-14 rounded-2xl bg-pearl flex items-center justify-center mb-5">
          <Target size={26} className="text-navy-400" />
        </div>
        <h2 className="text-xl font-bold text-navy-900 mb-2">Sin diagnostico activo</h2>
        <p className="text-sm text-[#6b7a8d] max-w-md mb-6">
          Ejecuta un analisis primero para generar el plan de accion completo.
        </p>
        <button onClick={() => navigate('/ingesta')} className="zn-btn-primary">
          Nuevo Analisis <ArrowRight size={14} className="ml-2" />
        </button>
      </div>
    );
  }

  /* ── Overrides (alertas criticas O1-O7) ───────────────────── */
  const overrides = resultados.overrides_activos || [];
  const catalogo = getCatalogoMetas() as any[];

  const overridesCompletos = overrides
    .map((oid: string) => {
      const cat = catalogo.find((c: any) => c.id === oid);
      if (!cat) return null;
      return {
        id: cat.id,
        nombre: cat.nombre || oid,
        pilar: cat.pilar || 'estructura',
        prioridad: 'critica',
        texto_consultor: cat.texto_consultor || '',
        texto_cliente: cat.texto_cliente || '',
        estrategias: cat.estrategias || [],
        impacto_eva_calculado: 0,
        valor_meta_calculado: null,
        valor_actual: null,
        meta_metrica: null,
      };
    })
    .filter(Boolean) as Array<{
      id: string;
      nombre: string;
      pilar: string;
      prioridad: string;
      texto_consultor: string;
      texto_cliente: string;
      estrategias: string[];
      impacto_eva_calculado: number;
      valor_meta_calculado: null;
      valor_actual: null;
      meta_metrica: null;
    }>;

  const metas = resultados.metas_activas;
  /* Orden jerárquico: Alta → Media → Baja, luego por impacto EVA */
  const pesoPrioridad: Record<string, number> = { alta: 3, media: 2, baja: 1 };
  const sortedMetas = [...metas].sort((a, b) => {
    const pa = pesoPrioridad[a.prioridad] || 0;
    const pb = pesoPrioridad[b.prioridad] || 0;
    if (pb !== pa) return pb - pa; /* prioridad descendente */
    return b.impacto_eva_calculado - a.impacto_eva_calculado; /* impacto descendente */
  });

  const porPilar = {
    rentabilidad: sortedMetas.filter(m => m.pilar === 'rentabilidad'),
    liquidez: sortedMetas.filter(m => m.pilar === 'liquidez'),
    estructura: sortedMetas.filter(m => m.pilar === 'estructura'),
  };

  const totalImpacto = sortedMetas.reduce((sum, m) => sum + m.impacto_eva_calculado, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-navy-900 tracking-tight">Plan de Accion Completo</h2>
          <p className="text-xs text-[#6b7a8d] mt-1">
            {resultados.empresa} &middot; {overridesCompletos.length + sortedMetas.length} estrategias &middot; Impacto total: {compactNumber(totalImpacto)}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-semibold px-2 py-1 rounded-full bg-danger/10 text-danger flex items-center gap-1">
            <ShieldAlert size={10} />
            {overridesCompletos.length} Criticas
          </span>
          <span className="text-[10px] font-semibold px-2 py-1 rounded-full bg-warning/10 text-warning-dark">
            {porPilar.rentabilidad.length} Rentabilidad
          </span>
          <span className="text-[10px] font-semibold px-2 py-1 rounded-full bg-steel-100 text-steel-500">
            {porPilar.liquidez.length} Liquidez
          </span>
          <span className="text-[10px] font-semibold px-2 py-1 rounded-full bg-pearl text-[#6b7a8d]">
            {porPilar.estructura.length} Estructura
          </span>
        </div>
      </div>

      {/* Resumen ejecutivo */}
      <div className="zn-card p-5 bg-navy-50/50">
        <div className="flex items-start gap-3">
          <Lightbulb size={16} className="text-warning flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-navy-900 mb-1">Resumen Ejecutivo</p>
            <p className="text-xs text-[#6b7a8d] leading-relaxed">
              Se identificaron <strong className="text-navy-900">{overridesCompletos.length + sortedMetas.length} oportunidades</strong> de mejora
              ({overridesCompletos.length > 0 ? `${overridesCompletos.length} criticas + ` : ''}{sortedMetas.length} regulares)
              con un impacto potencial combinado de <strong className="text-success">{compactNumber(totalImpacto)}</strong> en el Valor Economico Agregado.
            </p>
          </div>
        </div>
      </div>

      <Accordion type="multiple" className="space-y-3">
        {/* ═══ ALERTAS CRITICAS (Overrides O1-O7) ═══ */}
        {overridesCompletos.length > 0 && (
          <>
            <div className="flex items-center gap-2 px-1 pt-2">
              <ShieldAlert size={16} className="text-danger" />
              <p className="text-sm font-bold text-danger uppercase tracking-wider">
                Alertas de Supervivencia — Accion Inmediata
              </p>
              <div className="flex-1 h-px bg-danger/20 ml-2" />
            </div>
            {overridesCompletos.map((meta, i) => (
              <MetaAccordionItem
                key={meta.id}
                meta={meta}
                index={i}
                compactNumber={compactNumber}
                esOverride
              />
            ))}
          </>
        )}

        {/* ═══ METAS REGULARES (R, L, E) ═══ */}
        {sortedMetas.length > 0 && overridesCompletos.length > 0 && (
          <div className="flex items-center gap-2 px-1 pt-4">
            <ClipboardList size={16} className="text-navy-600" />
            <p className="text-sm font-bold text-navy-900 uppercase tracking-wider">
              Estrategias de Optimizacion
            </p>
            <div className="flex-1 h-px bg-navy-200 ml-2" />
          </div>
        )}
        {sortedMetas.map((meta, i) => (
          <MetaAccordionItem
            key={meta.id}
            meta={meta}
            index={overridesCompletos.length + i}
            compactNumber={compactNumber}
          />
        ))}
      </Accordion>

      {overridesCompletos.length === 0 && sortedMetas.length === 0 && (
        <div className="zn-card p-8 text-center">
          <AlertTriangle size={20} className="text-warning mx-auto mb-2" />
          <p className="text-sm text-[#6b7a8d]">No se encontraron estrategias activas para este diagnostico.</p>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   META ACCORDION ITEM — Fila expandible de cada estrategia
   ═══════════════════════════════════════════════════════════════ */

function MetaAccordionItem({
  meta,
  index,
  compactNumber,
  esOverride = false,
}: {
  meta: {
    id: string;
    nombre: string;
    texto_cliente: string;
    texto_consultor: string;
    descripcion_corta?: string;
    meta_metrica: string | null;
    prioridad: string;
    pilar: string;
    impacto_eva_calculado: number;
    valor_actual: number | null;
    valor_meta_calculado: number | null;
    estrategias?: string[];
  };
  index: number;
  compactNumber: (n: number) => string;
  esOverride?: boolean;
}) {
  const actual = meta.valor_actual;
  const metaVal = meta.valor_meta_calculado;
  const metrica = meta.meta_metrica;
  const esPct = metrica?.startsWith('margen') || metrica === 'roic' || metrica === 'wacc';
  const esDias = metrica === 'ccc' || metrica === 'dso' || metrica === 'doh' || metrica === 'dpo';
  const esX = metrica === 'cobertura_intereses' || metrica === 'razon_corriente';

  const fmtVal = (v: number | null) => {
    if (v == null) return 'N/A';
    if (esPct) return `${(v * 100).toFixed(1)}%`;
    if (esDias) return `${Math.round(v)} dias`;
    if (esX) return `${v.toFixed(2)}x`;
    return v.toFixed(2);
  };

  const impacto = meta.impacto_eva_calculado;
  const impactoPositivo = impacto > 0;
  const pilarColor =
    esOverride ? 'bg-danger/10 text-danger' :
    meta.pilar === 'rentabilidad' ? 'bg-warning/10 text-warning-dark' :
    meta.pilar === 'liquidez' ? 'bg-steel-100 text-steel-500' :
    'bg-pearl text-[#6b7a8d]';

  /* Nombre limpio sin jerga */
  const nombreLimpio = limpiarJerga(meta.nombre?.trim() || meta.meta_metrica || 'Estrategia');

  return (
    <AccordionItem value={meta.id} className={`zn-card overflow-hidden ${esOverride ? 'border-l-4 border-l-danger ring-1 ring-danger/10' : 'border-0'}`}>
      <AccordionTrigger className={`px-5 py-4 hover:no-underline transition-colors ${esOverride ? 'hover:bg-danger/[0.03] [&[data-state=open]]:bg-danger/[0.03]' : 'hover:bg-[#f8f9fb] [&[data-state=open]]:bg-[#f8f9fb]'}`}>
        <div className="flex items-center gap-3 text-left w-full pr-4">
          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 ${esOverride ? 'bg-danger text-white' : 'bg-navy-100 text-navy-700'}`}>
            {index + 1}
          </span>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-navy-900">{nombreLimpio}</span>
              {/* Badge de prioridad */}
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full flex-shrink-0 ${
                meta.prioridad === 'critica' ? 'bg-danger text-white' :
                meta.prioridad === 'alta' ? 'bg-warning text-white' :
                meta.prioridad === 'media' ? 'bg-amber-100 text-amber-700' :
                'bg-steel-100 text-steel-500'
              }`}>
                {meta.prioridad === 'critica' ? 'CRITICA' :
                 meta.prioridad === 'alta' ? 'ALTA' :
                 meta.prioridad === 'media' ? 'MEDIA' : 'BAJA'}
              </span>
            </div>
          </div>
          <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full capitalize flex-shrink-0 ${pilarColor}`}>
            {meta.pilar}
          </span>
          {!esOverride && (
            <span className={`text-xs font-bold flex-shrink-0 ${impactoPositivo ? 'text-success' : 'text-danger'}`}>
              {impactoPositivo ? '+' : ''}{compactNumber(impacto)}
            </span>
          )}
        </div>
      </AccordionTrigger>

      <AccordionContent className="px-5 pb-5">
        <div className="pt-2 border-t border-[#f0f2f5]">

          {/* Actual vs Meta (solo para metas regulares) */}
          {!esOverride && (actual != null || metaVal != null) && (
            <div className="flex items-center gap-4 my-3 px-3 py-2.5 bg-pearl rounded-lg">
              <div className="text-center flex-1">
                <p className="text-[10px] text-[#9ba5b3] uppercase tracking-wider">Actual</p>
                <p className="text-sm font-bold font-mono text-navy-900">{fmtVal(actual)}</p>
              </div>
              <div className="flex items-center gap-1">
                {impactoPositivo ? <ArrowUpRight size={14} className="text-success" /> :
                 impacto < 0 ? <ArrowDownRight size={14} className="text-danger" /> :
                 <Minus size={14} className="text-[#9ba5b3]" />}
              </div>
              <div className="text-center flex-1">
                <p className="text-[10px] text-[#9ba5b3] uppercase tracking-wider">Meta</p>
                <p className="text-sm font-bold font-mono text-success">{fmtVal(metaVal)}</p>
              </div>
              <div className="text-center flex-1 border-l border-[#e8ebf0] pl-4">
                <p className="text-[10px] text-[#9ba5b3] uppercase tracking-wider">Impacto</p>
                <p className={`text-sm font-bold font-mono ${impactoPositivo ? 'text-success' : 'text-danger'}`}>
                  {impactoPositivo ? '+' : ''}{compactNumber(impacto)}
                </p>
              </div>
            </div>
          )}

          {/* Contexto para el cliente (sin jerga) */}
          <p className="text-xs text-[#6b7a8d] leading-relaxed mb-3">
            {limpiarJerga(meta.texto_cliente)}
          </p>

          {/* Estrategias de accion del consultor — RENDERIZADO FIEL */}
          {meta.texto_consultor && (
            <div className="mt-3">
              <div className="flex items-center gap-1.5 mb-2">
                <ClipboardList size={12} className="text-navy-600" />
                <p className="text-[10px] font-semibold text-navy-700 uppercase tracking-wider">
                  Acciones recomendadas
                </p>
              </div>
              <EstrategiasLista estrategias={meta.estrategias} />
            </div>
          )}
        </div>
      </AccordionContent>
    </AccordionItem>
  );
}

/* ═══════════════════════════════════════════════════════════════
   ESTRATEGIAS LISTA — Renderiza las 4 estrategias del motor FIELMENTE

   motor.js v3 ahora incluye campo `estrategias: string[]` con 4 bullets
   exactos por meta. NO resumimos, NO truncamos, NO parseamos.
   Capitalizacion profesional: primera letra siempre mayuscula.
   ═══════════════════════════════════════════════════════════════ */

function EstrategiasLista({
  estrategias,
}: {
  estrategias?: string[];
}) {
  const lista = estrategias?.filter((s) => s?.trim().length > 0) || [];

  if (lista.length === 0) return null;

  return (
    <ul className="list-disc pl-5 space-y-2.5">
      {lista.map((e, i) => (
        <li key={i} className="text-xs text-navy-700 leading-relaxed pl-1">
          {cap(limpiarJerga(e))}
        </li>
      ))}
    </ul>
  );
}

/** Capitaliza la primera letra de un texto */
function cap(t: string): string {
  if (!t) return '';
  return t.charAt(0).toUpperCase() + t.slice(1);
}
