import { useNavigate } from 'react-router';
import { useDiagnostico } from '@/context/DiagnosticoContext';
import { useClasificacionColor } from '@/hooks/useClasificacionColor';
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from '@/components/ui/tabs';
import {
  BarChart3,
  ArrowRight,
  TrendingUp,
  Droplets,
  Landmark,
  CircleDollarSign,
  Info,
} from 'lucide-react';

/* ============================================================
   Diagnostico Detallado — Sala de Rayos X
   ============================================================ */

export default function DiagnosticoDetalle() {
  const { resultados } = useDiagnostico();
  const navigate = useNavigate();

  if (!resultados) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center animate-fade-in">
        <div className="w-14 h-14 rounded-2xl bg-pearl flex items-center justify-center mb-5">
          <BarChart3 size={26} className="text-navy-400" />
        </div>
        <h2 className="text-xl font-bold text-navy-900 mb-2">Sin diagnostico activo</h2>
        <p className="text-sm text-[#6b7a8d] max-w-md mb-6">
          Ejecuta un analisis primero para ver el diagnostico detallado.
        </p>
        <button onClick={() => navigate('/ingesta')} className="zn-btn-primary">
          Nuevo Analisis <ArrowRight size={14} className="ml-2" />
        </button>
      </div>
    );
  }

  const m = resultados.metricas;
  const c = resultados.clasificaciones;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-xl font-bold text-navy-900 tracking-tight">Diagnostico Detallado</h2>
        <p className="text-xs text-[#6b7a8d] mt-1">
          {resultados.empresa} &middot; Analisis por pilar financiero
        </p>
      </div>

      <Tabs defaultValue="rentabilidad" className="w-full">
        <TabsList className="mb-6 bg-pearl border border-[#e8ebf0] p-1 h-auto">
          <TabsTrigger value="rentabilidad" className="text-xs px-4 py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-navy-900">
            <TrendingUp size={13} className="mr-1.5" /> Rentabilidad
          </TabsTrigger>
          <TabsTrigger value="liquidez" className="text-xs px-4 py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-navy-900">
            <Droplets size={13} className="mr-1.5" /> Liquidez
          </TabsTrigger>
          <TabsTrigger value="estructura" className="text-xs px-4 py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-navy-900">
            <Landmark size={13} className="mr-1.5" /> Estructura
          </TabsTrigger>
        </TabsList>

        {/* TAB 1: RENTABILIDAD */}
        <TabsContent value="rentabilidad" className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard label="NOPAT" value={fmtMoney(m.nopat)} clasif={c.margen_ebitda}
              desc="Utilidad operativa despues de impuestos. Base para el EVA."
              icon={<CircleDollarSign size={16} />} />
            <MetricCard label="Margen Bruto" value={fmtPct(m.margen_bruto)} clasif={c.margen_bruto}
              desc="Ventas menos costo de ventas. Eficiencia de produccion."
              icon={<TrendingUp size={16} />} />
            <MetricCard label="Margen EBITDA" value={fmtPct(m.margen_ebitda)} clasif={c.margen_ebitda}
              desc="Utilidad operativa antes de depreciacion e intereses."
              icon={<TrendingUp size={16} />} />
          </div>
          <ProgressBar label="Margen Bruto" value={m.margen_bruto} bench={0.35} />
          <ProgressBar label="Margen EBITDA" value={m.margen_ebitda} bench={0.15} />
        </TabsContent>

        {/* TAB 2: LIQUIDEZ */}
        <TabsContent value="liquidez" className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard label="Ciclo de Conversion" value={fmtDias(m.ccc)} clasif={c.ccc}
              desc="Dias en convertir inversion en efectivo." icon={<Droplets size={16} />} />
            <MetricCard label="Dias de Cobro" value={fmtDias(m.dso)} clasif={c.dso}
              desc="Dias promedio para cobrar a clientes." icon={<Droplets size={16} />} />
            <MetricCard label="Dias de Inventario" value={fmtDias(m.doh)} clasif={c.doh}
              desc="Dias que el inventario permanece en almacen." icon={<Droplets size={16} />} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard label="Dias de Pago" value={fmtDias(m.dpo)} clasif="na"
              desc="Dias promedio para pagar a proveedores." icon={<Droplets size={16} />} />
            <MetricCard label="Razon Corriente" value={fmtNum(m.razon_corriente)} clasif={c.razon_corriente}
              desc="Activos corrientes / Pasivos corrientes." icon={<Droplets size={16} />} />
            <MetricCard label="Prueba Acida" value={fmtNum(m.prueba_acida)} clasif={c.prueba_acida}
              desc="(Activos corrientes - Inventarios) / Pasivos corrientes." icon={<Droplets size={16} />} />
          </div>
          <CicloVisual dso={m.dso} doh={m.doh} dpo={m.dpo} ccc={m.ccc} />
        </TabsContent>

        {/* TAB 3: ESTRUCTURA */}
        <TabsContent value="estructura" className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard label="Deuda / Patrimonio" value={fmtX(m.deuda_patrimonio)} clasif={c.deuda_patrimonio}
              desc="Apalancamiento financiero. Deuda total / Patrimonio." icon={<Landmark size={16} />} />
            <MetricCard label="Deuda / Activos" value={fmtPct(m.deuda_activos)} clasif={c.deuda_activos}
              desc="Porcentaje de activos financiados con deuda." icon={<Landmark size={16} />} />
            <MetricCard label="Cobertura de Intereses" value={fmtX(m.cobertura_intereses)} clasif={c.cobertura_intereses}
              desc="Utilidad operativa / Gastos financieros." icon={<Landmark size={16} />} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <MetricCard label="Dias de Caja" value={fmtDias(m.dias_caja)} clasif="na"
              desc="Dias que puede operar con el efectivo actual." icon={<Landmark size={16} />} />
            <MetricCard label="Deuda Neta / EBITDA" value={fmtX(m.deuda_neta_ebitda)} clasif="na"
              desc="Capacidad de pagar deuda con utilidades." icon={<Landmark size={16} />} />
          </div>
          <ProgressBar label="Deuda / Activos" value={m.deuda_activos} bench={0.50} invert />
        </TabsContent>
      </Tabs>

      {/* CTA: Continuar a Plan de Accion */}
      <div className="flex justify-center pt-4 pb-2">
        <button
          onClick={() => navigate('/resultados/plan-accion')}
          className="flex items-center gap-2 px-6 py-3 bg-navy-900 text-white text-sm font-semibold rounded-lg hover:bg-navy-800 transition-colors shadow-md"
        >
          Continuar a Plan de Accion
          <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   UTILS — Formateadores
   ============================================================ */

function fmtMoney(n: number | null) {
  if (n == null) return 'N/A';
  if (Math.abs(n) >= 1_000_000) return '$' + (n / 1_000_000).toFixed(2) + 'M';
  if (Math.abs(n) >= 1_000) return '$' + (n / 1_000).toFixed(0) + 'K';
  return '$' + n.toFixed(0);
}
function fmtPct(n: number | null) {
  return n != null ? (n * 100).toFixed(1) + '%' : 'N/A';
}
function fmtDias(n: number | null) {
  return n != null ? Math.round(n) + ' dias' : 'N/A';
}
function fmtNum(n: number | null) {
  return n != null ? n.toFixed(2) : 'N/A';
}
function fmtX(n: number | null) {
  return n != null ? n.toFixed(2) + 'x' : 'N/A';
}

/* ============================================================
   MetricCard
   ============================================================ */

function MetricCard({ label, value, clasif, desc, icon }: {
  label: string; value: string; clasif: string; desc: string; icon: React.ReactNode;
}) {
  const color = useClasificacionColor(clasif);
  const status = clasif === 'verde' ? 'Bueno' : clasif === 'amb' ? 'Precaucion' : clasif === 'rojo' ? 'Critico' : 'Neutro';

  return (
    <div className="zn-card p-5 hover:-translate-y-0.5 transition-transform">
      <div className="flex items-center justify-between mb-3">
        <span className="text-navy-400">{icon}</span>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color.dot }} />
          <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: color.text }}>
            {status}
          </span>
        </div>
      </div>
      <p className="text-xs text-[#6b7a8d] mb-1">{label}</p>
      <p className="text-xl font-bold font-mono text-navy-900 mb-2">{value}</p>
      <p className="text-[11px] text-[#9ba5b3] leading-relaxed">{desc}</p>
    </div>
  );
}

/* ============================================================
   ProgressBar — Barra vs benchmark
   ============================================================ */

function ProgressBar({ label, value, bench, invert }: {
  label: string; value: number; bench: number; invert?: boolean;
}) {
  const pct = Math.min(100, Math.max(0, (value / (bench * 2)) * 100));
  const good = invert ? value < bench : value >= bench;
  const color = good ? '#10b981' : value > bench * 1.5 || value < bench * 0.3 ? '#ef4444' : '#f59e0b';

  return (
    <div className="zn-card p-5">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium text-navy-700">{label}</span>
        <div className="flex items-center gap-3">
          <span className="text-xs text-[#9ba5b3]">Actual: <strong className="text-navy-900">{(value * 100).toFixed(1)}%</strong></span>
          <span className="text-xs text-[#9ba5b3]">Ref: <strong className="text-navy-900">{(bench * 100).toFixed(1)}%</strong></span>
        </div>
      </div>
      <div className="relative h-2.5 bg-[#e8ebf0] rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-700" style={{ width: pct + '%', backgroundColor: color }} />
        <div className="absolute top-0 w-0.5 h-full bg-navy-900/40" style={{ left: Math.min(100, (bench / (bench * 2)) * 100) + '%' }} />
      </div>
      <div className="flex items-center gap-1 mt-2">
        <Info size={10} className="text-[#b0b8c4]" />
        <span className="text-[10px] text-[#9ba5b3]">Linea vertical = valor de referencia del sector</span>
      </div>
    </div>
  );
}

/* ============================================================
   CicloVisual — Timeline del CCC
   ============================================================ */

function CicloVisual({ dso, doh, dpo, ccc }: {
  dso: number; doh: number; dpo: number; ccc: number;
}) {
  const total = dso + doh;
  const p1 = total > 0 ? (dso / total) * 100 : 50;
  const p2 = total > 0 ? (doh / total) * 100 : 50;

  return (
    <div className="zn-card p-5">
      <h4 className="text-sm font-semibold text-navy-900 mb-4">Desglose del Ciclo de Conversion de Efectivo</h4>

      {/* Barra proporcional */}
      <div className="flex h-4 rounded-full overflow-hidden mb-2">
    <div className="bg-warning flex items-center justify-center text-[9px] text-white font-bold" style={{ width: p1 + '%' }}>
      {p1 > 15 ? Math.round(dso) + 'd' : ''}
    </div>
    <div className="bg-steel-400 flex items-center justify-center text-[9px] text-white font-bold" style={{ width: p2 + '%' }}>
      {p2 > 15 ? Math.round(doh) + 'd' : ''}
    </div>
      </div>

      {/* Labels */}
      <div className="flex mb-5">
        <div className="text-center" style={{ width: p1 + '%' }}>
          <p className="text-[10px] font-semibold text-warning">Cobro</p>
          <p className="text-[10px] text-[#9ba5b3]">{Math.round(dso)} dias</p>
        </div>
        <div className="text-center" style={{ width: p2 + '%' }}>
          <p className="text-[10px] font-semibold text-steel-500">Inventario</p>
          <p className="text-[10px] text-[#9ba5b3]">{Math.round(doh)} dias</p>
        </div>
      </div>

      {/* Formula */}
      <div className="flex items-center justify-center gap-3 px-4 py-3 bg-pearl rounded-lg">
        <Step val={Math.round(dso)} label="Cobro" />
        <Op>+</Op>
        <Step val={Math.round(doh)} label="Inventario" />
        <Op>-</Op>
        <Step val={Math.round(dpo)} label="Pago" />
        <Op>=</Op>
        <div className="text-center px-3 py-1 rounded-md bg-navy-900">
          <p className="text-xs font-bold text-white">{Math.round(ccc)}d</p>
          <p className="text-[9px] text-steel-400">CCC</p>
        </div>
      </div>
    </div>
  );
}

function Step({ val, label }: { val: number; label: string }) {
  return (
    <div className="text-center">
      <p className="text-xs font-bold text-navy-900">{val}d</p>
      <p className="text-[9px] text-[#9ba5b3]">{label}</p>
    </div>
  );
}

function Op({ children }: { children: string }) {
  return <span className="text-lg text-[#b0b8c4]">{children}</span>;
}
