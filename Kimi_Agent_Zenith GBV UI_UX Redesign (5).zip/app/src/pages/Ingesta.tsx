import { useState, useCallback } from 'react';
import { useDiagnostico } from '@/context/DiagnosticoContext';
import { parsearExcel } from '@/lib/excelParser';
import RevisionExcel from '@/components/ingesta/RevisionExcel';
import WizardManual from '@/components/ingesta/WizardManual';
import type { IngestaFormData } from '@/types/motor';
import {
  Upload,
  FileSpreadsheet,
  Keyboard,
  ArrowRight,
  ShieldCheck,
  Zap,
  Download,
} from 'lucide-react';

/**
 * ================================================================
 * Zenith GBV — Ingesta.tsx (Dual Flow)
 *
 * Tres modos:
 *   1. 'dropzone' — Pantalla limpia con dropzone + boton manual
 *   2. 'excel'    — Fast-track: RevisionExcel con datos extraidos
 *   3. 'manual'   — Wizard de 5 pasos (placeholder)
 * ================================================================ */

type ModoIngesta = 'dropzone' | 'excel' | 'manual';

export default function Ingesta() {
  const { guardarFormData } = useDiagnostico();
  const [modo, setModo] = useState<ModoIngesta>('dropzone');
  const [isDragging, setIsDragging] = useState(false);

  // Datos extraidos del Excel
  const [extractedData, setExtractedData] = useState<IngestaFormData | null>(null);
  const [fileName, setFileName] = useState('');
  const [error, setError] = useState<string | null>(null);

  // ── Drag & Drop ────────────────────────────────────────────
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files.length > 0) {
      procesarArchivo(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      procesarArchivo(e.target.files[0]);
      e.target.value = '';
    }
  }, []);

  // ── Descargar plantilla oficial adjunta ────────────────────
  const descargarPlantilla = useCallback(() => {
    const link = document.createElement('a');
    link.href = '/Machote_ZenithGBV.xlsx';
    link.download = 'Machote_ZenithGBV.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, []);

  const procesarArchivo = async (file: File) => {
    setError(null);
    setFileName(file.name);

    try {
      const formData = await parsearExcel(file);
      setExtractedData(formData);
      guardarFormData(formData);
      setModo('excel');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error desconocido al procesar el archivo';
      setError(msg);
    }
  };

  const handleVolver = () => {
    setModo('dropzone');
    setExtractedData(null);
    setFileName('');
    setError(null);
  };

  // ── Render ─────────────────────────────────────────────────
  if (modo === 'excel' && extractedData) {
    return (
      <div className="flex-1 py-6 animate-slide-up">
        <RevisionExcel
          fileName={fileName}
          onVolver={handleVolver}
        />
      </div>
    );
  }

  if (modo === 'manual') {
    return (
      <div className="flex-1 py-6 animate-slide-up px-4">
        <WizardManual onVolver={handleVolver} />
      </div>
    );
  }

  // Modo dropzone (default)
  return (
    <div className="flex-1 flex flex-col items-center justify-center animate-fade-in px-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-navy-900 mb-5 shadow-lg">
            <Upload size={26} className="text-steel-400" />
          </div>
          <h2 className="text-2xl font-bold text-navy-900 tracking-tight mb-2">
            Nuevo Analisis
          </h2>
          <p className="text-sm text-[#6b7a8d] max-w-md mx-auto leading-relaxed">
            Sube tu Machote de Excel con los datos de la empresa, o llena los
            datos manualmente paso a paso.
          </p>
        </div>

        {/* Error */}
        {error && (
          <div className="mb-4 p-4 rounded-lg bg-danger-light border border-danger/20 flex items-start gap-3">
            <span className="text-danger flex-shrink-0 mt-0.5">Error</span>
            <p className="text-sm text-danger whitespace-pre-line">{error}</p>
          </div>
        )}

        {/* Dropzone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => document.getElementById('file-input')?.click()}
          className={`
            relative cursor-pointer rounded-xl border-2 border-dashed
            transition-all duration-200 text-center
            ${isDragging
              ? 'border-steel-400 bg-steel-50 shadow-upload-active scale-[1.01]'
              : 'border-[#c8cdd5] bg-white hover:border-steel-400 hover:bg-steel-50/50 hover:shadow-upload'
            }
          `}
          style={{ padding: '3.5rem 2rem' }}
        >
          <input
            id="file-input"
            type="file"
            accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            className="hidden"
            onChange={handleFileInput}
          />

          <div className="flex flex-col items-center">
            <div
              className={`
                w-16 h-16 rounded-2xl flex items-center justify-center mb-4
                transition-all duration-200
                ${isDragging ? 'bg-steel-400 text-white shadow-lg' : 'bg-pearl text-navy-400'}
              `}
            >
              <FileSpreadsheet size={28} />
            </div>

            <p className="text-base font-semibold text-navy-900 mb-1">
              {isDragging ? 'Suelta el archivo aqui' : 'Arrastra tu Machote de Excel'}
            </p>
            <p className="text-sm text-[#6b7a8d] mb-3">
              o haz clic para seleccionarlo
            </p>

            <div className="flex items-center gap-3 text-[11px] text-[#9ba5b3]">
              <span className="flex items-center gap-1">
                <ShieldCheck size={10} />
                .xlsx
              </span>
              <span className="w-1 h-1 rounded-full bg-[#c8cdd5]" />
              <span>Max. 10 MB</span>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-4 my-6">
          <div className="flex-1 h-px bg-[#e8ebf0]" />
          <span className="text-xs font-medium text-[#9ba5b3] uppercase tracking-wider">o</span>
          <div className="flex-1 h-px bg-[#e8ebf0]" />
        </div>

        {/* Boton manual */}
        <button
          onClick={(e) => { e.stopPropagation(); setModo('manual'); }}
          className="w-full zn-btn-secondary py-3"
        >
          <Keyboard size={15} className="mr-2 text-navy-400" />
          Llenar datos manualmente
          <ArrowRight size={14} className="ml-2 text-navy-400" />
        </button>

        {/* Boton descargar plantilla */}
        <button
          onClick={(e) => { e.stopPropagation(); descargarPlantilla(); }}
          className="w-full mt-3 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-md border border-[#d1d8e2] bg-white text-xs font-medium text-[#6b7a8d] hover:text-navy-900 hover:border-navy-300 transition-colors"
        >
          <Download size={14} />
          Descargar Plantilla de Excel
        </button>

        {/* Tip */}
        <div className="mt-6 flex items-start gap-3 p-3 rounded-lg bg-pearl">
          <Zap size={14} className="text-steel-500 flex-shrink-0 mt-0.5" />
          <p className="text-[11px] text-[#6b7a8d] leading-relaxed">
            <span className="font-medium text-navy-700">Consejo:</span> Si tienes el
            Excel del cliente, la ruta mas rapida es arrastrarlo aqui. El sistema
            extrae automaticamente los datos de balance y estado de resultados.
          </p>
        </div>
      </div>
    </div>
  );
}


