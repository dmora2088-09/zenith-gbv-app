import { useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router';
import { useDiagnostico } from '@/context/DiagnosticoContext';
import { useFormatters } from '@/hooks/useFormatters';
import { generarReporteTecnico } from '@/lib/generarReporteTecnico';
import { FileDown, FileText, ArrowLeft, Loader2 } from 'lucide-react';
import ReporteEjecutivoPrint from '@/components/reportes/ReporteEjecutivoPrint';

/**
 * ================================================================
 * Reportes — Centro de Entregables Profesionales
 *
 * Dos formatos:
 *   A) Resumen Ejecutivo (PDF) — One-pager para el dueño
 *      Usa ReporteEjecutivoPrint.tsx → abre en ventana → print()
 *   B) Diagnóstico Técnico (Excel) — Reporte exhaustivo para consultor
 *      Usa exceljs para rellenar plantilla con datos reales
 * ================================================================ */

/* ── Helper: semáforo texto ─────────────────────────────────── */
function semaforoTexto(valor: string): string {
  if (valor === 'verde') return 'Óptimo';
  if (valor === 'amarillo') return 'En Riesgo';
  if (valor === 'rojo') return 'Crítico';
  return 'Estable';
}

export default function Reportes() {
  const { resultados, inputs } = useDiagnostico();
  const { compactNumber } = useFormatters();
  const navigate = useNavigate();
  const [cargandoExcel, setCargandoExcel] = useState(false);

  /* Ref del div oculto con el reporte ejecutivo para impresión */
  const printRef = useRef<HTMLDivElement>(null);

  /* ═══════════════════════════════════════════════════════════
     BOTÓN A: Resumen Ejecutivo → abrir ventana + print()
     ═══════════════════════════════════════════════════════════ */
  const abrirResumenEjecutivo = useCallback(() => {
    if (!printRef.current) return;

    /* Copiar el HTML del reporte oculto */
    const html = printRef.current.innerHTML;

    /* Abrir ventana nueva */
    const w = window.open('', '_blank', 'width=900,height=1200');
    if (!w) return;

    /* Escribir HTML completo con estilos */
    w.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Resumen Ejecutivo — Zenith GBV</title>
          <script src="https://cdn.tailwindcss.com"><\/script>
          <style>
            @media print {
              @page { size: A4; margin: 0; }
              body { margin: 0; background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            }
          </style>
        </head>
        <body class="bg-white">
          ${html}
          <script>
            window.onload = function() {
              setTimeout(function() { window.print(); }, 300);
            };
          <\/script>
        </body>
      </html>
    `);
    w.document.close();
  }, []);

  /* ═══════════════════════════════════════════════════════════
     BOTÓN B: Diagnóstico Técnico → generar Excel con exceljs
     ═══════════════════════════════════════════════════════════ */
  const descargarDiagnosticoTecnico = useCallback(async () => {
    if (!inputs || !resultados) return;
    setCargandoExcel(true);
    try {
      const blob = await generarReporteTecnico(inputs, resultados);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Zenith_DiagnosticoTecnico_${resultados.empresa.replace(/\s+/g, '_')}.xlsx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Error generando Excel:', e);
      alert('Error generando el reporte. Intente de nuevo.');
    } finally {
      setCargandoExcel(false);
    }
  }, [inputs, resultados]);

  /* ═══════════════════════════════════════════════════════════
     PREPARAR DATOS PARA ReporteEjecutivoPrint
     ═══════════════════════════════════════════════════════════ */
  const datosEjecutivo = resultados
    ? {
        nombreEmpresa: resultados.empresa,
        fecha: new Date().toLocaleDateString('es-MX', { day: '2-digit', month: 'long', year: 'numeric' }),
        folio: `ZEN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
        score: resultados.score_global,
        veredicto: resultados.veredicto,
        evaActual: `$${compactNumber(resultados.metricas.eva)}`,
        evaProyectado: `$${compactNumber(resultados.metricas.eva + resultados.metricas.capital_invertido * 0.02)}`,
        deltaEva: `+$${compactNumber(resultados.metricas.capital_invertido * 0.02)}`,
        semaforoRentabilidad: semaforoTexto(resultados.semaforos.rentabilidad),
        semaforoLiquidez: semaforoTexto(resultados.semaforos.liquidez),
        semaforoEstructura: semaforoTexto(resultados.semaforos.estructura),
        roic: `${(resultados.metricas.roic * 100).toFixed(1)}%`,
        wacc: `${(resultados.metricas.wacc * 100).toFixed(1)}%`,
        margenNeto: `${(resultados.metricas.margen_neto * 100).toFixed(1)}%`,
        razonCorriente: resultados.metricas.razon_corriente?.toFixed(2) || 'N/A',
        diasCaja: `${Math.round(resultados.metricas.dias_caja || 0)} días`,
        deRatio: `${(resultados.metricas.deuda_patrimonio || 0).toFixed(2)}x`,
        cobertura: `${(resultados.metricas.cobertura_intereses || 0).toFixed(1)}x`,
        alertas: (resultados.overrides_activos || [])
          .map((oid: string) => {
            const cat = (window as any).MotorVBM?.CATALOGO_METAS?.find((c: any) => c.id === oid);
            return cat?.texto_consultor || oid;
          })
          .filter(Boolean),
        estrategiasPrioridadAlta: resultados.metas_activas
          .filter((m) => m.prioridad === 'alta')
          .slice(0, 6)
          .map((m, i) => ({
            fase: i < 2 ? 'Días 1-30' : i < 4 ? 'Días 31-60' : 'Días 61-90',
            estrategia: m.nombre,
            kpi: m.meta_metrica || `${compactNumber(m.impacto_eva_calculado)} EVA`,
          })),
      }
    : null;

  /* ── Sin diagnóstico ─────────────────────────────────────── */
  if (!resultados) {
    return (
      <div className="space-y-8 animate-fade-in max-w-3xl mx-auto">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-navy-900 tracking-tight">Reportes</h2>
          <p className="text-xs text-[#6b7a8d] mt-1">Genera entregables profesionales para el cliente</p>
        </div>
        <div className="zn-card p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-pearl flex items-center justify-center mx-auto mb-4">
            <FileText size={26} className="text-navy-400" />
          </div>
          <h3 className="text-lg font-bold text-navy-900 mb-2">Sin análisis disponible</h3>
          <p className="text-sm text-[#6b7a8d] max-w-md mx-auto mb-6">
            Primero ejecuta un análisis para generar reportes.
          </p>
          <button onClick={() => navigate('/ingesta')} className="zn-btn-primary inline-flex items-center gap-2">
            <ArrowLeft size={14} />
            Nuevo Análisis
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in max-w-3xl mx-auto">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-navy-900 tracking-tight">Reportes</h2>
        <p className="text-xs text-[#6b7a8d] mt-1">
          Entregables profesionales para {resultados.empresa}
        </p>
      </div>

      {/* Tarjeta del análisis */}
      <div className="zn-card p-6 border-l-4 border-l-gold">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-[#6b7a8d] mb-1">
              Último Análisis Realizado
            </p>
            <h3 className="text-lg font-bold text-navy-900">{resultados.empresa}</h3>
            <p className="text-xs text-[#6b7a8d] mt-1">
              {resultados.sector} &middot; Score: {resultados.score_global}/100 &middot; EVA: {compactNumber(resultados.metricas.eva)}
            </p>
          </div>
          <span className={`text-xs font-bold px-3 py-1 rounded-full ${resultados.crea_valor ? 'bg-success-light text-success' : 'bg-danger-light text-danger'}`}>
            {resultados.veredicto}
          </span>
        </div>
      </div>

      {/* Dos opciones de reporte */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

        {/* A) RESUMEN EJECUTIVO (PDF) */}
        <div className="zn-card p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-navy-900 flex items-center justify-center">
              <FileDown size={18} className="text-gold" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-navy-900">Resumen Ejecutivo</h4>
              <p className="text-[10px] text-[#6b7a8d]">Formato: PDF &middot; Para el dueño</p>
            </div>
          </div>
          <p className="text-xs text-[#6b7a8d] mb-5 leading-relaxed">
            One-pager con score, EVA, semáforos, alertas críticas y hoja de ruta a 90 días.
            Listo para imprimir o guardar como PDF.
          </p>
          <button
            onClick={abrirResumenEjecutivo}
            disabled={!datosEjecutivo}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-navy-900 text-white text-xs font-semibold rounded-lg hover:bg-navy-800 transition-colors disabled:opacity-40"
          >
            <FileDown size={14} />
            Generar Resumen Ejecutivo
          </button>
        </div>

        {/* B) DIAGNÓSTICO TÉCNICO (Excel) */}
        <div className="zn-card p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-navy-900 flex items-center justify-center">
              <FileText size={18} className="text-gold" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-navy-900">Diagnóstico Técnico</h4>
              <p className="text-[10px] text-[#6b7a8d]">Formato: Excel (.xlsx) &middot; Para el consultor</p>
            </div>
          </div>
          <p className="text-xs text-[#6b7a8d] mb-5 leading-relaxed">
            Reporte exhaustivo con todas las métricas, plan de acción completo,
            variables de entrada y cálculos detallados.
          </p>
          <button
            onClick={descargarDiagnosticoTecnico}
            disabled={cargandoExcel || !inputs}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-navy-900 text-white text-xs font-semibold rounded-lg hover:bg-navy-800 transition-colors disabled:opacity-40"
          >
            {cargandoExcel ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} />}
            {cargandoExcel ? 'Generando Excel...' : 'Descargar Diagnóstico Técnico'}
          </button>
        </div>
      </div>

      {/* Reporte Ejecutivo oculto — se clona a ventana nueva para imprimir */}
      {datosEjecutivo && (
        <div ref={printRef} className="hidden">
          <ReporteEjecutivoPrint data={datosEjecutivo} />
        </div>
      )}
    </div>
  );
}
