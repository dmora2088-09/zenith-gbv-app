/**
 * Zenith GBV — Home (redireccion legacy)
 *
 * Las rutas ahora apuntan a:
 *   /          → Inicio
 *   /dashboard → DashboardResumen
 */

export { default } from './Inicio';
