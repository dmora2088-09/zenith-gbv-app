import { useDiagnostico } from '@/context/DiagnosticoContext';
import { useFormatters } from '@/hooks/useFormatters';
import { useClasificacionColor } from '@/hooks/useClasificacionColor';
import { TrendingUp, Target, CircleDollarSign, Zap, AlertTriangle, Activity } from 'lucide-react';

export default function DashboardVBM() {
  const { resultados } = useDiagnostico();
  const { pct, fmt, compactNumber } = useFormatters();

  if (!resultados) return null;

  const m = resultados.metricas;
  const c = resultados.clasificaciones;

  const metricasCards = [
    { label: 'ROIC', value: pct(m.roic), clasif: c.roic, desc: 'Retorno sobre capital invertido', icon: <TrendingUp size={16} /> },
    { label: 'WACC', value: pct(m.wacc), clasif: 'na', desc: 'Costo promedio ponderado de capital', icon: <Target size={16} /> },
    { label: 'EVA', value: compactNumber(m.eva), clasif: m.eva >= 0 ? 'verde' : 'rojo', desc: 'Valor economico agregado', icon: <CircleDollarSign size={16} /> },
    { label: 'Spread', value: pct(m.spread), clasif: m.spread >= 0 ? 'verde' : 'rojo', desc: 'ROIC - WACC', icon: <Zap size={16} /> },
    { label: 'NOPAT', value: compactNumber(m.nopat), clasif: m.nopat > 0 ? 'verde' : 'rojo', desc: 'Utilidad neta operativa despues de impuestos', icon: <CircleDollarSign size={16} /> },
    { label: 'NOPCAF', value: compactNumber(m.nopcaf), clasif: m.nopcaf > 0 ? 'verde' : 'rojo', desc: 'Flujo de caja operativo real', icon: <Activity size={16} /> },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-navy-900">Metricas VBM — Value Based Management</h2>
      </div>

      {/* Grid de metricas */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {metricasCards.map((card) => {
          const color = useClasificacionColor(card.clasif);
          return (
            <div key={card.label} className="zn-card p-5">
              <div className="flex items-center gap-2 mb-3 text-navy-400">
                {card.icon}
                <span className="zn-metric-label">{card.label}</span>
              </div>
              <div className="flex items-baseline gap-2 mb-1">
                <span className="zn-metric-value">{card.value}</span>
                {card.clasif !== 'na' && (
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color.dot }} />
                )}
              </div>
              <p className="text-[11px] text-[#6b7a8d]">{card.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Creacion vs Destruccion de valor */}
      <div className="zn-card">
        <div className="zn-card-header">
          <span className="zn-card-title">Creacion de Valor</span>
        </div>
        <div className="zn-card-body">
          <div className={`p-4 rounded-lg ${m.eva >= 0 ? 'bg-success-light/50' : 'bg-danger-light/50'} mb-4`}>
            <div className="flex items-center gap-3">
              {m.eva >= 0 ? <TrendingUp size={20} className="text-success" /> : <AlertTriangle size={20} className="text-danger" />}
              <div>
                <p className={`text-sm font-bold ${m.eva >= 0 ? 'text-success' : 'text-danger'}`}>
                  {m.eva >= 0 ? 'La empresa CREA valor' : 'La empresa DESTRUYE valor'}
                </p>
                <p className="text-xs text-[#6b7a8d] mt-0.5">
                  {m.eva >= 0
                    ? 'El ROIC supera al WACC. Cada peso invertido genera retornos por encima del costo del capital.'
                    : 'El ROIC esta por debajo del WACC. El negocio consume mas capital del que genera.'}
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-pearl text-center">
              <div className="text-[10px] font-semibold text-[#6b7a8d] uppercase tracking-wider mb-1">Capital Invertido</div>
              <div className="text-lg font-bold text-navy-900">{fmt(m.capital_invertido)}</div>
            </div>
            <div className="p-4 rounded-lg bg-pearl text-center">
              <div className="text-[10px] font-semibold text-[#6b7a8d] uppercase tracking-wider mb-1">NOPAT</div>
              <div className="text-lg font-bold text-navy-900">{fmt(m.nopat)}</div>
            </div>
            <div className="p-4 rounded-lg bg-pearl text-center">
              <div className="text-[10px] font-semibold text-[#6b7a8d] uppercase tracking-wider mb-1">Charge Capital (WACC x CI)</div>
              <div className="text-lg font-bold text-navy-900">{fmt(m.capital_invertido * m.wacc)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Metas activas con impacto EVA */}
      <div className="zn-card">
        <div className="zn-card-header">
          <span className="zn-card-title">Impacto en EVA por Recomendacion</span>
        </div>
        <div className="zn-card-body">
          <div className="space-y-2">
            {resultados.metas_reporte.map((meta) => {
              const impacto = meta.impacto_eva_calculado || 0;
              const width = Math.min(100, Math.abs(impacto) / 10000 * 100);
              return (
                <div key={meta.id} className="flex items-center gap-3">
                  <span className="text-[11px] font-medium text-navy-800 w-48 truncate flex-shrink-0">{meta.nombre}</span>
                  <div className="flex-1 h-4 bg-pearl rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${impacto >= 0 ? 'bg-success' : 'bg-danger'}`}
                      style={{ width: `${Math.max(2, width)}%` }}
                    />
                  </div>
                  <span className={`text-[11px] font-semibold w-20 text-right ${impacto >= 0 ? 'text-success' : 'text-danger'}`}>
                    {impacto >= 0 ? '+' : ''}{compactNumber(impacto)}
                  </span>
                </div>
              );
            })}
          </div>

          {/* EVA proyectado */}
          <div className="mt-4 pt-4 border-t border-[#e8ebf0] flex items-center justify-between">
            <span className="text-sm font-semibold text-navy-900">EVA Proyectado (con acciones)</span>
            <span className={`text-lg font-bold ${resultados.cascada_eva.eva_proyectado >= 0 ? 'text-success' : 'text-danger'}`}>
              {compactNumber(resultados.cascada_eva.eva_proyectado)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
