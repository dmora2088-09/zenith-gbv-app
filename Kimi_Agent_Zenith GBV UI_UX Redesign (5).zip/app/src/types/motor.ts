/**
 * ================================================================
 * Zenith GBV — Tipado completo del Motor (motor.js v2)
 *
 * Dos capas de tipos:
 *   1. IngestaFormData  → datos crudos de los 5 pasos del formulario
 *   2. IngestaInputsPlano → objeto plano de 52+ campos que el motor espera
 *
 * Paridad 1:1 con finalizarYDiagnosticar() de ingesta(2).js
 * ================================================================
 */

/* ═══════════════════════════════════════════════════════════════
   PASOS DEL FORMULARIO (datos crudos, estructurados por paso)
   ═══════════════════════════════════════════════════════════════ */

export interface Paso1aNegocio {
  nombre_empresa: string;
  periodo_analizar: number;
  sector_id: string;
  numero_empleados: number;
  ventas_aprox: number;
  moneda: 'MXN' | 'USD';
  num_periodos: 1 | 2 | 3;
  regimen: 'PM_30' | 'RESICO_10' | 'RESICO_11' | 'RESICO_15' | 'RESICO_20' | 'RESICO_25' | 'PFAE_OTRO';
  tasa_impuesto: number;
  /** Tasa ISR manual para regimen PFAE (viene del Excel o wizard) */
  tasa_isr_manual: number | null;
  es_informal: boolean;
  // derivados
  sector_tipo: 'comercio' | 'industria' | 'servicios';
  es_micro: boolean;
}

export interface Paso1bAjustes {
  retiros_propietario: number;
  gastos_personales_empresa: number;
  ventas_no_facturadas: number;
  sueldo_imputado: number;
  deuda_fintech: number;
  deuda_tarjeta: number;
  deuda_agiotista: number;
  deuda_sombra: number;      // derivado: fintech + tarjeta + agiotista
}

export interface Paso1cEstadoResultados {
  ventas: number;
  cogs: number;
  gastos_adm: number;
  gastos_vta: number;
  da: number;                 // depreciacion y amortizacion
  ing_no_op: number;          // ingresos no operativos
  gto_no_op: number;          // gastos no operativos
  gastos_financieros: number;
  capex: number;
}

export interface Paso1dBalance {
  caja_bancos: number;
  cuentas_por_cobrar: number;
  inventarios: number;
  otros_activos_corrientes: number;
  activos_fijos_netos: number;
  otros_activos_no_corrientes: number;
  cuentas_por_pagar: number;
  deuda_financiera_cp: number;
  otros_pasivos_corrientes: number;
  deuda_financiera_lp: number;
  otros_pasivos_nc: number;
  capital_social: number;
  utilidades_retenidas: number;
  // Derivados del balance (calculados en recopilar1D)
  patrimonio: number;         // capital_social + utilidades_retenidas
  activo_total: number;       // suma de todos los activos
  pasivo_total: number;       // suma de todos los pasivos
  deuda_total: number;        // cp + lp
}

export interface Paso1eOperativos {
  credito_pct: number;        // 0..1
  Kd: number;                 // 0..1
  prima_pyme: number;         // 0..1
  dso_manual: number | null;
  doh_manual: number | null;
  dpo_manual: number | null;
}

/**
 * Datos crudos del formulario completo (5 pasos).
 * Se usa como estado del formulario de ingesta.
 */
export interface IngestaFormData {
  p1a: Paso1aNegocio;
  p1b: Paso1bAjustes;
  p1c: Paso1cEstadoResultados;
  p1d: Paso1dBalance;
  p1e: Paso1eOperativos;
}

/* ═══════════════════════════════════════════════════════════════
   OBJETO PLANO — 52+ campos que ejecutarDiagnostico() espera
   (paridad 1:1 con ingesta(2).js :: finalizarYDiagnosticar)
   ═══════════════════════════════════════════════════════════════ */

export interface IngestaInputsPlano {
  // ── p1a: Negocio ───────────────────────────────────────────
  nombre_empresa: string;
  periodo: number;
  regimen: 'ISR_PM' | 'RESICO' | 'PFAE';
  tasa_impuesto: number;
  numero_empleados: number;
  sector_tipo: string;
  es_informal: boolean;
  moneda: string;
  sector_id: string;

  // ── p1c: Estado de Resultados ──────────────────────────────
  ventas: number;
  cogs: number;
  gastos_administracion: number;
  gastos_ventas: number;
  depreciacion_amortizacion: number;
  ingresos_no_operativos: number;
  gastos_no_operativos: number;
  gastos_financieros: number;
  capex: number;

  // ── p1d: Balance General ───────────────────────────────────
  caja_bancos: number;
  cuentas_por_cobrar: number;
  inventarios: number;
  otros_activos_corrientes: number;
  activos_fijos_netos: number;
  otros_activos_no_corrientes: number;
  cuentas_por_pagar: number;
  deuda_financiera_cp: number;
  otros_pasivos_corrientes: number;
  deuda_financiera_lp: number;
  otros_pasivos_nc: number;
  capital_social: number;
  utilidades_retenidas: number;
  patrimonio: number;
  activo_total: number;
  pasivo_total: number;
  deuda_total: number;

  // ── p1b: Ajustes ───────────────────────────────────────────
  retiros_propietario: number;
  gastos_personales: number;          // alias de gastos_personales_empresa
  gastos_personales_empresa: number;  // el motor usa este nombre
  ventas_no_facturadas: number;
  sueldo_imputado: number;
  deuda_sombra: number;
  deuda_fintech: number;
  deuda_tarjeta: number;
  deuda_agiotista: number;
  atrasos_sat: boolean;

  // ── p1e: Operativos ────────────────────────────────────────
  credito_pct: number;
  Kd: number;
  kd_efectivo: number;
  prima_pyme: number;

  // ── Derivados (calculados en recopilar/finalizar) ──────────
  pasivos_corrientes: number;
  capital_invertido: number;
  ebitda: number;
  opex: number;
  impuestos_anuales: number;
  es_micro: boolean;

  // ── Campos usados por normalizarInputs (motor.js §5) ───────
  margen_bruto_pct?: number;         // usado en ajuste informal
  ktno_anterior?: number;            // para NOPCAF ΔKTNO
}

/* ═══════════════════════════════════════════════════════════════
   RESULTADOS DEL MOTOR
   ═══════════════════════════════════════════════════════════════ */

export type ClasificacionVAR = 'verde' | 'amarillo' | 'rojo' | 'na';

export interface Metricas {
  // Resultados intermedios
  utilidad_bruta: number;
  ebit: number;
  ebitda: number;
  nopat: number;
  utilidad_neta: number;
  ktno: number;
  capital_invertido: number;

  // WACC
  wacc: number;
  ke: number;
  kd: number;

  // Creacion de valor
  roic: number;
  eva: number;
  spread: number;
  nopcaf: number;

  // CCC
  dso: number;
  doh: number;
  dpo: number;
  ccc: number;
  velocidad_efectivo: number | null;

  // Liquidez
  razon_corriente: number | null;
  prueba_acida: number | null;
  dias_caja: number | null;

  // Estructura
  deuda_neta: number;
  deuda_total: number;
  deuda_activos: number;
  deuda_patrimonio: number;
  cobertura_intereses: number | null;
  deuda_neta_ebitda: number | null;

  // Margenes
  margen_bruto: number;
  margen_ebitda: number;
  margen_operativo: number;
  margen_neto: number;

  // Rentabilidad patrimonial
  roe: number;
  roa: number;

  // Punto de equilibrio
  punto_equilibrio_pesos: number | null;
  punto_equilibrio_dias: number | null;

  // Z-Score
  z_score: number | null;
  z_zona: 'Segura' | 'Gris' | 'Quiebra' | null;

  // Resumen balance
  activo_total: number;
  patrimonio: number;
  caja_bancos: number;
  cuentas_por_cobrar: number;
  inventarios: number;
  deuda_financiera_cp: number;
  deuda_financiera_lp: number;

  // Ref
  sector_id: string;
  ventas: number;
  cogs: number;
  opex: number;
}

export interface Clasificaciones {
  margen_bruto: ClasificacionVAR;
  margen_ebitda: ClasificacionVAR;
  margen_operativo: ClasificacionVAR;
  margen_neto: ClasificacionVAR;
  roic: ClasificacionVAR;
  ccc: ClasificacionVAR;
  dso: ClasificacionVAR;
  doh: ClasificacionVAR;
  dpo: ClasificacionVAR;
  razon_corriente: ClasificacionVAR;
  prueba_acida: ClasificacionVAR;
  deuda_activos: ClasificacionVAR;
  deuda_patrimonio: ClasificacionVAR;
  cobertura_intereses: ClasificacionVAR;
}

export type PilarMeta = 'rentabilidad' | 'liquidez' | 'estructura' | 'cruzada';
export type PrioridadMeta = 'critica' | 'alta' | 'media' | 'baja';

export interface MetaReporte {
  id: string;
  nombre: string;
  pilar: PilarMeta;
  prioridad: PrioridadMeta;
  texto_consultor: string;
  texto_cliente: string;
  /** 4 bullets de accion estrategica (motor.js v3+) */
  estrategias?: string[];
  impacto_eva_calculado: number;
  valor_meta_calculado: number | null;
  valor_actual: number | null;
  meta_metrica: string | null;
  excluir_reporte?: boolean;
  origen?: string;
}

export interface FODA {
  eje_interno: number;
  eje_externo: number;
  cuadrante: 'Ofensiva' | 'Defensiva' | 'Reingenieria' | 'Supervivencia';
  pregunta_guia: string;
}

export interface CascadaEVA {
  cascada: Array<{
    meta_id: string;
    meta_nombre: string;
    impacto_eva: number;
    eva_acumulado: number;
  }>;
  eva_proyectado: number;
}

export interface Semaforos {
  rentabilidad: ClasificacionVAR;
  liquidez: ClasificacionVAR;
  estructura: ClasificacionVAR;
}

/**
 * Resultado completo de ejecutarDiagnostico()
 */
export interface DiagnosticoResult {
  error: false;
  empresa: string;
  sector: string;
  sector_id: string;
  estrato: string;
  periodo: number;
  veredicto: string;
  crea_valor: boolean;
  score_global: number;
  metricas: Metricas;
  clasificaciones: Clasificaciones;
  overrides_activos: string[];
  metas_activas: MetaReporte[];
  metas_reporte: MetaReporte[];
  foda: FODA;
  cascada_eva: CascadaEVA;
  semaforos: Semaforos;
  benchmarks_sector: unknown;
  wacc_params: unknown;
  timestamp: string;
  texto_cliente: string;
  /** Z-Score de Altman (agregado por adapter para acceso directo) */
  z_score: number | null;
  /** Zona de riesgo según Z-Score: Segura > 2.9, Gris 1.8-2.9, Quiebra < 1.8 */
  z_zona: 'Segura' | 'Gris' | 'Quiebra' | null;
  /** Alertas derivadas de overrides_activos (nombres legibles) */
  alertas: string[];
}

export interface DiagnosticoError {
  error: true;
  mensajes: string[];
}

/**
 * Tipo unión: resultado exitoso o error
 */
export type DiagnosticoOutput = DiagnosticoResult | DiagnosticoError;

/* ═══════════════════════════════════════════════════════════════
   MOTOR GLOBAL (window.MotorVBM)
   ═══════════════════════════════════════════════════════════════ */

export interface MotorGlobal {
  ejecutarDiagnostico: (
    inputs: Record<string, unknown>,
    sectorId: string
  ) => DiagnosticoOutput;
  calcularMetricas: (
    inputs: Record<string, unknown>,
    sectorId: string
  ) => Metricas;
  calcularWACC: (
    inputs: Record<string, unknown>,
    sectorId: string
  ) => {
    wacc: number;
    ke: number;
    kd: number;
    beta_L: number;
    prima_pyme: number;
    D: number;
    E: number;
    V: number;
  };
  clasificarTodasLasMetricas: (
    m: Metricas,
    sid: string,
    inputs: Record<string, unknown>
  ) => Clasificaciones;
  verificarOverrides: (
    m: Metricas,
    i: Record<string, unknown>,
    sid: string
  ) => string[];
  activarMetas: (
    m: Metricas,
    i: Record<string, unknown>,
    sid: string
  ) => MetaReporte[];
  calcularScoreGlobal: (
    m: Metricas,
    c: Clasificaciones
  ) => number;
  calcularFODA: (
    m: Metricas,
    c: Clasificaciones,
    sid: string
  ) => FODA;
  BENCHMARKS: Record<string, unknown>;
  WACC_PARAMS: Record<string, unknown>;
  CATALOGO_METAS: unknown[];
  MACRO: Record<string, number | string>;
  fmt: (n: number, d?: number) => string;
  fmtPct: (n: number, d?: number) => string;
  fmtX: (n: number, d?: number) => string;
  fmtDias: (n: number) => string;
  colorSemaforo: (c: ClasificacionVAR) => string;
  emojiSemaforo: (c: ClasificacionVAR) => string;
}

declare global {
  interface Window {
    MotorVBM: MotorGlobal;
  }
}
