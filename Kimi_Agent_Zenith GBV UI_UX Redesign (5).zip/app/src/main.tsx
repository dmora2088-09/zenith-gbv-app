import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { HashRouter } from 'react-router'
import { DiagnosticoProvider } from './context/DiagnosticoContext'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <HashRouter>
      <DiagnosticoProvider>
        <App />
      </DiagnosticoProvider>
    </HashRouter>
  </StrictMode>,
)
